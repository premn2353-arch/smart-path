# Campus Navigator

Build a modern, responsive web application called "Smart Path Navigation for Our Campus".

Project Goal

The application helps students, staff, and visitors easily navigate inside a large college campus. Users should be able to scan a QR code at the main gate, select their destination, and get the best route to reach that location.

Core Features for the First Version

1. Home Page

   

   - Project name: Smart Path Navigation for Our Campus

   - Short description explaining the purpose of the application

   - "Scan QR Code" button

   - "Start Navigation" button

   - Clean and modern college-themed UI

2. QR Code Navigation

   

   - Create a QR scanning page.

   - When the user scans a QR code at the main gate, identify the starting location as "Main Gate".

   - After scanning, redirect the user to the destination selection page.

   - For the first prototype, also provide a manual option to select "Main Gate" as the starting point.

3. Destination Selection

   Create a searchable destination list with sample locations:

   

   - CSE Department

   - Computer Lab 1

   - Computer Lab 2

   - Library

   - Seminar Hall

   - Principal Office

   - Administrative Office

   - Canteen

   - Classroom 101

   - Classroom 201

   - Classroom 301

4. Indoor Campus Map

   

   - Create a simple 2D indoor campus map.

   - Display buildings, rooms, corridors, stairs, and lifts.

   - Show the user's current location.

   - Show the selected destination.

   - Use clear visual markers for the starting point and destination.

5. Shortest Path Navigation

   

   - Model the campus as a graph with locations as nodes and paths as edges.

   - Implement a shortest-path algorithm such as A* or Dijkstra's algorithm.

   - Calculate the shortest route from the user's current location to the selected destination.

   - Display the calculated route clearly on the map.

   - Show estimated distance and approximate walking time.

   - Provide step-by-step navigation instructions.

6. Floor Navigation

   

   - Support multiple floors such as Ground Floor, First Floor, and Second Floor.

   - Clearly show when the user needs to use a staircase or lift.

   - Example:

     Main Gate → Reception → Staircase 1 → First Floor → CSE Department.

7. Route Options

   Provide route preferences:

   

   - Shortest Route

   - Fastest Route

   - Lift Route

   - Staircase Route

   - Wheelchair Accessible Route

8. Emergency Route

   

   - Add an Emergency Navigation option.

   - Show the nearest emergency exit from the user's current location.

   - Avoid blocked or unavailable paths when calculating the emergency route.

9. Admin Dashboard

   Create a basic admin dashboard where an administrator can:

   

   - Add or edit buildings

   - Add or edit rooms

   - Add floors

   - Add stairs and lifts

   - Add destinations

   - Update routes

   - Mark a route as temporarily unavailable

Technical Requirements

- Use React and TypeScript for the frontend.

- Use a clean, modular component structure.

- Use Supabase for database and backend services if appropriate.

- Make the application fully responsive for mobile, tablet, and desktop.

- Use a modern, clean, professional UI.

- Use reusable components.

- Keep the navigation algorithm separate from the UI so it can be expanded later.

- Use sample campus data initially.

- Do not add unnecessary features yet.

- Build the application in a way that allows future features such as live occupancy percentage, crowd prediction, AI assistant, voice navigation, canteen ordering, and real-time location tracking to be added later.

Important

First build the complete working foundation and UI for the above features. Make sure the QR flow, destination selection, indoor map, shortest-path calculation, floor navigation, and admin dashboard work together as one application.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://indoor-routes.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/7c41038e-e47f-4af1-b6c9-a833da6c9a0c).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
