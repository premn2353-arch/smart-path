import { useMemo } from "react";
import {
  Building2,
  DoorOpen,
  FlaskConical,
  LogOut,
  Presentation,
  Toilet,
  MapPin,
} from "lucide-react";
import type { CampusEdge, CampusNode, FloorId, LocationType } from "@/lib/campus/model";
import { usePlanAspect } from "@/lib/campus/use-plan-aspect";

interface Props {
  nodes: CampusNode[];
  edges: CampusEdge[];
  floor: FloorId;
  pathNodeIds?: string[];
  startId?: string;
  endId?: string;
  /** Location the user checked in at with a QR code. */
  currentId?: string;
  /** Optional real floor-plan image stretched across the 0-100 grid. */
  planImage?: string;
  /** 1 = fit floor, >1 zooms in around `center`. */
  zoom?: number;
  center?: { x: number; y: number };
  showLabels?: boolean;
  onSelectNode?: (node: CampusNode) => void;
  className?: string;
}

export const TYPE_COLORS: Record<LocationType, string> = {
  gate: "var(--color-primary)",
  entrance: "var(--color-primary)",
  room: "var(--color-card)",
  department: "#6366f1",
  lab: "#0ea5e9",
  corridor: "var(--color-muted-foreground)",
  stair: "#8b5cf6",
  lift: "#14b8a6",
  exit: "#f59e0b",
  washroom: "#64748b",
  landmark: "var(--color-card)",
};

const ICONS: Partial<Record<LocationType, React.ComponentType<any>>> = {
  gate: DoorOpen,
  entrance: DoorOpen,
  department: Building2,
  lab: FlaskConical,
  landmark: Presentation,
  washroom: Toilet,
  exit: LogOut,
};

const LABELLED: LocationType[] = [
  "gate",
  "entrance",
  "room",
  "department",
  "lab",
  "landmark",
  "washroom",
  "exit",
];

export function CampusMap({
  nodes,
  edges,
  floor,
  pathNodeIds = [],
  startId,
  endId,
  currentId,
  planImage,
  zoom = 1,
  center = { x: 50, y: 50 },
  showLabels = true,
  onSelectNode,
  className,
}: Props) {
  const nodesOnFloor = useMemo(() => nodes.filter((n) => n.floor === floor), [nodes, floor]);
  const nodeMap = useMemo(() => new Map(nodes.map((n) => [n.id, n])), [nodes]);
  const edgesOnFloor = useMemo(
    () =>
      edges.filter((e) => {
        const a = nodeMap.get(e.from);
        const b = nodeMap.get(e.to);
        return a && b && a.floor === floor && b.floor === floor;
      }),
    [edges, nodeMap, floor],
  );

  const pathSet = useMemo(() => new Set(pathNodeIds), [pathNodeIds]);
  const pathEdges = useMemo(() => {
    const s = new Set<string>();
    for (let i = 0; i < pathNodeIds.length - 1; i++) {
      s.add(`${pathNodeIds[i]}::${pathNodeIds[i + 1]}`);
      s.add(`${pathNodeIds[i + 1]}::${pathNodeIds[i]}`);
    }
    return s;
  }, [pathNodeIds]);

  // The plan image defines the canvas shape; node coordinates stay 0-100 % and
  // are mapped into that shape so markers align automatically.
  const aspect = usePlanAspect(planImage);
  const H = aspect ? 100 / aspect : 100;
  const Y = (y: number) => (y * H) / 100;

  const w = 100 / Math.max(1, zoom);
  const h = H / Math.max(1, zoom);
  const minX = Math.min(Math.max(center.x - w / 2, 0), 100 - w);
  const minY = Math.min(Math.max(Y(center.y) - h / 2, 0), H - h);
  const s = Math.max(0.7, 1 / Math.max(1, zoom)); // scale text/strokes with zoom

  return (
    <svg
      viewBox={`${minX} ${minY} ${w} ${h}`}
      preserveAspectRatio="xMidYMid meet"
      className={className}
      style={aspect ? { aspectRatio: String(aspect) } : undefined}
      role="img"
      aria-label={`Indoor campus map, floor ${floor}`}
    >
      {planImage ? (
        <image href={planImage} x="0" y="0" width="100" height={H} preserveAspectRatio="none" />
      ) : (
        <>
          <rect x="2" y="2" width="96" height="96" rx="3" fill="var(--color-muted)" stroke="var(--color-border)" strokeWidth="0.3" />
          {Array.from({ length: 9 }).map((_, i) => (
            <g key={i} stroke="var(--color-border)" strokeWidth="0.1" opacity="0.4">
              <line x1={(i + 1) * 10} y1="2" x2={(i + 1) * 10} y2="98" />
              <line x1="2" y1={(i + 1) * 10} x2="98" y2={(i + 1) * 10} />
            </g>
          ))}
        </>
      )}

      {/* Corridors / walkable connections */}
      {edgesOnFloor.map((e, i) => {
        const a = nodeMap.get(e.from)!;
        const b = nodeMap.get(e.to)!;
        const isPath = pathEdges.has(`${e.from}::${e.to}`);
        return (
          <line
            key={i}
            x1={a.x}
            y1={Y(a.y)}
            x2={b.x}
            y2={Y(b.y)}
            stroke={
              e.blocked
                ? "var(--color-destructive)"
                : isPath
                  ? "var(--color-primary)"
                  : "var(--color-muted-foreground)"
            }
            strokeWidth={(isPath ? 1.2 : 0.4) * s}
            strokeDasharray={e.blocked ? "1 1" : isPath ? undefined : "0.6 0.6"}
            opacity={isPath ? 1 : 0.6}
            strokeLinecap="round"
          />
        );
      })}

      {/* Locations */}
      {nodesOnFloor.map((n) => {
        const isStart = n.id === startId;
        const isEnd = n.id === endId;
        const isCurrent = n.id === currentId;
        const onPath = pathSet.has(n.id);
        const isVertical = n.type === "stair" || n.type === "lift";
        const Icon = ICONS[n.type];
        const fill = isStart || isCurrent
          ? "var(--color-primary)"
          : isEnd
            ? "var(--color-destructive)"
            : onPath
              ? "var(--color-primary)"
              : TYPE_COLORS[n.type];
        const radius = (isStart || isEnd || isCurrent ? 2.6 : n.type === "corridor" ? 1.1 : 2) * s;
        return (
          <g
            key={n.id}
            onClick={onSelectNode ? () => onSelectNode(n) : undefined}
            style={onSelectNode ? { cursor: "pointer" } : undefined}
          >
            {isCurrent && (
              <circle cx={n.x} cy={Y(n.y)} r={4.4 * s} fill="var(--color-primary)" opacity="0.2" />
            )}
            <circle
              cx={n.x}
              cy={Y(n.y)}
              r={radius}
              fill={fill}
              stroke="var(--color-foreground)"
              strokeWidth={(isStart || isEnd || isCurrent ? 0.5 : 0.2) * s}
            />
            {isVertical && (
              <text
                x={n.x}
                y={Y(n.y) + 0.8 * s}
                fontSize={2.4 * s}
                textAnchor="middle"
                fill="#ffffff"
                fontWeight={700}
              >
                {n.type === "lift" ? "L" : "S"}
              </text>
            )}
            {Icon && !isStart && !isEnd && !isCurrent && (
              <Icon
                x={n.x - 1.3 * s}
                y={Y(n.y) - 1.3 * s}
                width={2.6 * s}
                height={2.6 * s}
                stroke="var(--color-foreground)"
                strokeWidth={2.4}
                fill="none"
              />
            )}
            {(isStart || isCurrent || isEnd) && (
              <MapPin
                x={n.x - 1.4 * s}
                y={Y(n.y) - 1.4 * s}
                width={2.8 * s}
                height={2.8 * s}
                stroke="var(--color-primary-foreground)"
                strokeWidth={2.4}
                fill="none"
              />
            )}
            {showLabels && (LABELLED.includes(n.type) || isStart || isEnd || isCurrent) && (
              <text
                x={n.x}
                y={Y(n.y) - 3.2 * s}
                fontSize={2.4 * s}
                textAnchor="middle"
                fill="var(--color-foreground)"
                fontWeight={isStart || isEnd || isCurrent ? 700 : 500}
              >
                {n.label}
              </text>
            )}
          </g>
        );
      })}
    </svg>
  );
}
