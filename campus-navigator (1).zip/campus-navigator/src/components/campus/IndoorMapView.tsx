import { useState } from "react";
import { Minus, Plus, RotateCcw } from "lucide-react";
import { CampusMap } from "./CampusMap";
import { Button } from "@/components/ui/button";
import type { CampusEdge, CampusNode, FloorId } from "@/lib/campus/model";

interface Props {
  nodes: CampusNode[];
  edges: CampusEdge[];
  floor: FloorId;
  planImage?: string;
  currentId?: string;
  startId?: string;
  endId?: string;
  pathNodeIds?: string[];
  onSelectNode?: (node: CampusNode) => void;
}

const LEGEND: { label: string; color: string }[] = [
  { label: "Department", color: "#6366f1" },
  { label: "Lab", color: "#0ea5e9" },
  { label: "Staircase", color: "#8b5cf6" },
  { label: "Lift", color: "#14b8a6" },
  { label: "Emergency exit", color: "#f59e0b" },
  { label: "Washroom", color: "#64748b" },
];

/** Interactive floor map with zoom controls and a legend. */
export function IndoorMapView({ onSelectNode, ...map }: Props) {
  const [zoom, setZoom] = useState(1);
  const [center, setCenter] = useState({ x: 50, y: 50 });

  return (
    <div className="space-y-3">
      <div className="relative overflow-hidden rounded-2xl border border-border/60 bg-card">
        <CampusMap
          {...map}
          zoom={zoom}
          center={center}
          onSelectNode={(n) => {
            setCenter({ x: n.x, y: n.y });
            onSelectNode?.(n);
          }}
          className={map.planImage ? "block h-auto w-full" : "aspect-square w-full"}
        />
        <div className="absolute right-3 top-3 flex flex-col gap-1">
          <Button size="icon" variant="secondary" aria-label="Zoom in" onClick={() => setZoom((z) => Math.min(4, z + 0.5))}>
            <Plus className="h-4 w-4" />
          </Button>
          <Button size="icon" variant="secondary" aria-label="Zoom out" onClick={() => setZoom((z) => Math.max(1, z - 0.5))}>
            <Minus className="h-4 w-4" />
          </Button>
          <Button
            size="icon"
            variant="secondary"
            aria-label="Reset view"
            onClick={() => {
              setZoom(1);
              setCenter({ x: 50, y: 50 });
            }}
          >
            <RotateCcw className="h-4 w-4" />
          </Button>
        </div>
      </div>
      <ul className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
        {LEGEND.map((l) => (
          <li key={l.label} className="flex items-center gap-1.5">
            <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: l.color }} />
            {l.label}
          </li>
        ))}
      </ul>
    </div>
  );
}
