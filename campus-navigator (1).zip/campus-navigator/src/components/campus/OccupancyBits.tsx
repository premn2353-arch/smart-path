import { Users } from "lucide-react";
import { cn } from "@/lib/utils";
import type { CrowdStatus, OccupancyView } from "@/lib/campus/occupancy";

export const statusClasses: Record<CrowdStatus, { text: string; bg: string; bar: string }> = {
  low: { text: "text-emerald-600", bg: "bg-emerald-500/10", bar: "bg-emerald-500" },
  medium: { text: "text-amber-600", bg: "bg-amber-500/10", bar: "bg-amber-500" },
  high: { text: "text-orange-600", bg: "bg-orange-500/10", bar: "bg-orange-500" },
  over: { text: "text-destructive", bg: "bg-destructive/10", bar: "bg-destructive" },
};

export function CrowdBadge({ view, className }: { view: OccupancyView; className?: string }) {
  const s = statusClasses[view.status];
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium",
        s.bg,
        s.text,
        className,
      )}
    >
      <Users className="h-3 w-3" />
      {view.percent}% · {view.label}
    </span>
  );
}

export function OccupancyBar({ view }: { view: OccupancyView }) {
  const s = statusClasses[view.status];
  return (
    <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
      <div
        className={cn("h-full rounded-full transition-all", s.bar)}
        style={{ width: `${Math.min(100, view.percent)}%` }}
      />
    </div>
  );
}

export function formatUpdated(ts: number): string {
  if (!ts) return "sample data";
  const diff = Date.now() - ts;
  if (diff < 60_000) return "just now";
  const mins = Math.round(diff / 60_000);
  if (mins < 60) return `${mins} min ago`;
  return new Date(ts).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

export function OccupancyCard({
  view,
  action,
}: {
  view: OccupancyView;
  action?: React.ReactNode;
}) {
  const s = statusClasses[view.status];
  return (
    <div className="rounded-2xl border border-border/60 bg-card p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="truncate font-semibold">{view.name}</div>
          <div className="text-xs text-muted-foreground">
            {view.enabled ? `Current: ${view.current} / ${view.capacity}` : "Tracking disabled"}
          </div>
        </div>
        <div className={cn("shrink-0 text-right text-2xl font-bold tabular-nums", s.text)}>
          {view.enabled ? `${view.percent}%` : "—"}
        </div>
      </div>
      {view.enabled && (
        <>
          <div className="mt-3">
            <OccupancyBar view={view} />
          </div>
          <div className="mt-2 flex items-center justify-between text-xs">
            <span className={cn("font-medium", s.text)}>{view.label}</span>
            <span className="text-muted-foreground">Updated {formatUpdated(view.updatedAt)}</span>
          </div>
        </>
      )}
      {action && <div className="mt-3">{action}</div>}
    </div>
  );
}
