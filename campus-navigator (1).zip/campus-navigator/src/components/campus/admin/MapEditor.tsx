import { useMemo, useRef, useState } from "react";
import { Link2, MousePointer2, MapPin, Trash2, Unlink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { campusStore, useCampus } from "@/lib/campus/store";
import { TYPE_COLORS } from "@/components/campus/CampusMap";
import { usePlanAspect } from "@/lib/campus/use-plan-aspect";
import type { CampusEdge, CampusNode, FloorId, LocationType } from "@/lib/campus/model";
import { cn } from "@/lib/utils";

/** Location types the admin can pick from. */
export const LOCATION_TYPES: { value: LocationType; label: string }[] = [
  { value: "room", label: "Room / Classroom" },
  { value: "lab", label: "Laboratory" },
  { value: "department", label: "Department" },
  { value: "landmark", label: "Office / Library / Canteen / Reception" },
  { value: "corridor", label: "Corridor" },
  { value: "stair", label: "Staircase" },
  { value: "lift", label: "Lift" },
  { value: "entrance", label: "Entrance" },
  { value: "gate", label: "Main Gate" },
  { value: "exit", label: "Emergency Exit" },
  { value: "washroom", label: "Washroom" },
];

type Tool = "select" | "add" | "connect";

const dist = (a: CampusNode, b: CampusNode) =>
  Math.max(1, Math.round(Math.hypot(a.x - b.x, a.y - b.y)));

const uid = (label: string, taken: Set<string>) => {
  const base =
    label.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "loc";
  let id = base;
  let i = 2;
  while (taken.has(id)) id = `${base}-${i++}`;
  return id;
};

/** Interactive editor: place locations and draw walkable paths on the floor plan. */
export function MapEditor() {
  const { nodes, edges, floors, buildings } = useCampus();
  const [floorId, setFloorId] = useState<FloorId>(floors[0]?.id ?? 0);
  const floor = floors.find((f) => f.id === floorId) ?? floors[0];
  const [tool, setTool] = useState<Tool>("select");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [linkFrom, setLinkFrom] = useState<string | null>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  // Canvas matches the uploaded plan's shape; coordinates stay 0-100 %.
  const aspect = usePlanAspect(floor?.planImage);
  const H = aspect ? 100 / aspect : 100;
  const Y = (y: number) => (y * H) / 100;

  const floorNodes = useMemo(() => nodes.filter((n) => n.floor === floorId), [nodes, floorId]);
  const nodeMap = useMemo(() => new Map(nodes.map((n) => [n.id, n])), [nodes]);
  const floorEdges = useMemo(
    () =>
      edges.filter((e) => {
        const a = nodeMap.get(e.from);
        const b = nodeMap.get(e.to);
        return a && b && (a.floor === floorId || b.floor === floorId);
      }),
    [edges, nodeMap, floorId],
  );
  const selected = selectedId ? (nodeMap.get(selectedId) ?? null) : null;

  function handleCanvasClick(evt: React.MouseEvent<SVGSVGElement>) {
    if (tool !== "add" || !svgRef.current) return;
    const rect = svgRef.current.getBoundingClientRect();
    const x = Math.round(((evt.clientX - rect.left) / rect.width) * 1000) / 10;
    const y = Math.round(((evt.clientY - rect.top) / rect.height) * 1000) / 10;
    const label = `New location ${floorNodes.length + 1}`;
    const id = uid(label, new Set(nodes.map((n) => n.id)));
    campusStore.addNode({
      id,
      label,
      type: "room",
      floor: floorId,
      buildingId: floor?.buildingId ?? buildings[0]?.id,
      x,
      y,
      isDestination: true,
      accessible: true,
    });
    setSelectedId(id);
    setTool("select");
  }

  function handleNodeClick(n: CampusNode) {
    if (tool === "connect") {
      if (!linkFrom) {
        setLinkFrom(n.id);
        return;
      }
      if (linkFrom === n.id) {
        setLinkFrom(null);
        return;
      }
      const a = nodeMap.get(linkFrom)!;
      campusStore.addEdge({
        from: a.id,
        to: n.id,
        weight: a.floor === n.floor ? dist(a, n) : 6,
        kind: "walk",
        accessible: true,
      });
      setLinkFrom(null);
      return;
    }
    setSelectedId(n.id);
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        {floors.map((f) => (
          <button
            key={f.id}
            onClick={() => {
              setFloorId(f.id);
              setLinkFrom(null);
            }}
            className={cn(
              "rounded-full border border-border/60 px-3 py-1.5 text-sm transition hover:bg-muted",
              f.id === floorId && "border-primary bg-primary text-primary-foreground hover:bg-primary",
            )}
          >
            {f.name}
          </button>
        ))}
        <div className="ml-auto flex gap-1 rounded-lg border border-border/60 p-1">
          <ToolButton active={tool === "select"} onClick={() => setTool("select")} icon={<MousePointer2 className="h-4 w-4" />} label="Select" />
          <ToolButton active={tool === "add"} onClick={() => setTool("add")} icon={<MapPin className="h-4 w-4" />} label="Add location" />
          <ToolButton
            active={tool === "connect"}
            onClick={() => {
              setTool("connect");
              setLinkFrom(null);
            }}
            icon={<Link2 className="h-4 w-4" />}
            label="Connect"
          />
        </div>
      </div>

      <p className="text-sm text-muted-foreground">
        {tool === "add"
          ? "Click anywhere on the plan to place a new location."
          : tool === "connect"
            ? linkFrom
              ? `Now click the second location to connect it to "${nodeMap.get(linkFrom)?.label}".`
              : "Click the first location of the walkable path."
            : "Click a marker to edit its details."}
      </p>

      <div className="grid gap-4 lg:grid-cols-[1.4fr_1fr]">
        <div className="overflow-hidden rounded-2xl border border-border/60 bg-card">
          <svg
            ref={svgRef}
            viewBox={`0 0 100 ${H}`}
            preserveAspectRatio="xMidYMid meet"
            style={aspect ? { aspectRatio: String(aspect) } : undefined}
            className={cn(aspect ? "block h-auto w-full" : "aspect-square w-full", tool === "add" && "cursor-crosshair")}
            onClick={handleCanvasClick}
            role="img"
            aria-label={`Floor plan editor for ${floor?.name}`}
          >
            {floor?.planImage ? (
              <image href={floor.planImage} x="0" y="0" width="100" height={H} preserveAspectRatio="none" />
            ) : (
              <rect x="0" y="0" width="100" height={H} fill="var(--color-muted)" />
            )}
            {Array.from({ length: 9 }).map((_, i) => (
              <g key={i} stroke="var(--color-border)" strokeWidth="0.1" opacity="0.35">
                <line x1={(i + 1) * 10} y1="0" x2={(i + 1) * 10} y2={H} />
                <line x1="0" y1={Y((i + 1) * 10)} x2="100" y2={Y((i + 1) * 10)} />
              </g>
            ))}

            {floorEdges.map((e, i) => {
              const a = nodeMap.get(e.from)!;
              const b = nodeMap.get(e.to)!;
              if (a.floor !== b.floor) return null;
              return (
                <line
                  key={i}
                  x1={a.x}
                  y1={Y(a.y)}
                  x2={b.x}
                  y2={Y(b.y)}
                  stroke={e.blocked ? "var(--color-destructive)" : "var(--color-primary)"}
                  strokeWidth={0.6}
                  strokeDasharray={e.blocked ? "1 1" : undefined}
                  opacity={0.8}
                />
              );
            })}

            {floorNodes.map((n) => (
              <g
                key={n.id}
                onClick={(evt) => {
                  evt.stopPropagation();
                  handleNodeClick(n);
                }}
                style={{ cursor: "pointer" }}
              >
                <circle
                  cx={n.x}
                  cy={Y(n.y)}
                  r={n.id === selectedId || n.id === linkFrom ? 2.8 : 2}
                  fill={TYPE_COLORS[n.type]}
                  stroke={n.id === linkFrom ? "var(--color-destructive)" : "var(--color-foreground)"}
                  strokeWidth={n.id === selectedId || n.id === linkFrom ? 0.6 : 0.25}
                />
                <text x={n.x} y={Y(n.y) - 3.4} fontSize={2.3} textAnchor="middle" fill="var(--color-foreground)">
                  {n.label}
                </text>
              </g>
            ))}
          </svg>
        </div>

        <div className="space-y-4">
          {selected ? (
            <NodeInspector node={selected} onDeleted={() => setSelectedId(null)} />
          ) : (
            <div className="rounded-2xl border border-border/60 bg-card p-4 text-sm text-muted-foreground">
              No location selected.
            </div>
          )}

          <div className="rounded-2xl border border-border/60 bg-card">
            <div className="border-b border-border/60 px-4 py-2 text-sm font-semibold">
              Connections on this floor
            </div>
            <div className="max-h-72 divide-y divide-border/60 overflow-auto">
              {floorEdges.map((e, i) => (
                <EdgeRow key={i} edge={e} label={`${nodeMap.get(e.from)?.label} → ${nodeMap.get(e.to)?.label}`} />
              ))}
              {floorEdges.length === 0 && (
                <div className="px-4 py-6 text-center text-sm text-muted-foreground">
                  No connections yet.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <FloorLinker />
    </div>
  );
}

function ToolButton({ active, onClick, icon, label }: { active: boolean; onClick: () => void; icon: React.ReactNode; label: string }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-sm transition",
        active ? "bg-primary text-primary-foreground" : "hover:bg-muted",
      )}
    >
      {icon}
      <span className="hidden sm:inline">{label}</span>
    </button>
  );
}

function NodeInspector({ node, onDeleted }: { node: CampusNode; onDeleted: () => void }) {
  const { buildings, floors } = useCampus();
  return (
    <div className="space-y-3 rounded-2xl border border-border/60 bg-card p-4">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold">Edit location</h3>
        <code className="text-xs text-muted-foreground">{node.id}</code>
      </div>
      <div>
        <Label className="mb-1.5 block text-xs text-muted-foreground">Name</Label>
        <Input key={`${node.id}-label`} className="h-9" defaultValue={node.label} onBlur={(e) => campusStore.updateNode(node.id, { label: e.target.value })} />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <Label className="mb-1.5 block text-xs text-muted-foreground">Type</Label>
          <select
            className="h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
            value={node.type}
            onChange={(e) => campusStore.updateNode(node.id, { type: e.target.value as LocationType })}
          >
            {LOCATION_TYPES.map((t) => (
              <option key={t.value} value={t.value}>{t.label}</option>
            ))}
          </select>
        </div>
        <div>
          <Label className="mb-1.5 block text-xs text-muted-foreground">Room code</Label>
          <Input key={`${node.id}-code`} className="h-9" defaultValue={node.code ?? ""} onBlur={(e) => campusStore.updateNode(node.id, { code: e.target.value })} />
        </div>
        <div>
          <Label className="mb-1.5 block text-xs text-muted-foreground">Building</Label>
          <select
            className="h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
            value={node.buildingId ?? ""}
            onChange={(e) => campusStore.updateNode(node.id, { buildingId: e.target.value })}
          >
            <option value="">—</option>
            {buildings.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
          </select>
        </div>
        <div>
          <Label className="mb-1.5 block text-xs text-muted-foreground">Floor</Label>
          <select
            className="h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
            value={String(node.floor)}
            onChange={(e) => campusStore.updateNode(node.id, { floor: Number(e.target.value) })}
          >
            {floors.map((f) => <option key={f.id} value={String(f.id)}>{f.name}</option>)}
          </select>
        </div>
        <div>
          <Label className="mb-1.5 block text-xs text-muted-foreground">X (0–100)</Label>
          <Input key={`${node.id}-x`} type="number" className="h-9" defaultValue={node.x} onBlur={(e) => campusStore.updateNode(node.id, { x: Number(e.target.value) })} />
        </div>
        <div>
          <Label className="mb-1.5 block text-xs text-muted-foreground">Y (0–100)</Label>
          <Input key={`${node.id}-y`} type="number" className="h-9" defaultValue={node.y} onBlur={(e) => campusStore.updateNode(node.id, { y: Number(e.target.value) })} />
        </div>
      </div>
      <div className="flex flex-wrap gap-4 text-sm">
        <label className="flex items-center gap-2">
          <Switch checked={!!node.isDestination} onCheckedChange={(v) => campusStore.updateNode(node.id, { isDestination: v })} />
          Destination
        </label>
        <label className="flex items-center gap-2">
          <Switch checked={!!node.accessible} onCheckedChange={(v) => campusStore.updateNode(node.id, { accessible: v })} />
          Accessible
        </label>
        <label className="flex items-center gap-2">
          <Switch checked={!!node.hasQr} onCheckedChange={(v) => campusStore.updateNode(node.id, { hasQr: v })} />
          QR checkpoint
        </label>
        <label className="flex items-center gap-2">
          <Switch checked={!!node.isEmergencyExit} onCheckedChange={(v) => campusStore.updateNode(node.id, { isEmergencyExit: v })} />
          Emergency exit
        </label>
      </div>
      <Button
        size="sm"
        variant="ghost"
        className="text-destructive"
        onClick={() => {
          if (confirm(`Delete "${node.label}"?`)) {
            campusStore.removeNode(node.id);
            onDeleted();
          }
        }}
      >
        <Trash2 className="mr-2 h-4 w-4" /> Delete location
      </Button>
    </div>
  );
}

function EdgeRow({ edge, label }: { edge: CampusEdge; label: string }) {
  return (
    <div className="flex flex-wrap items-center gap-2 px-4 py-2 text-sm">
      <span className="min-w-[8rem] flex-1 truncate">{label}</span>
      <select
        className="h-8 rounded-md border border-input bg-background px-1.5 text-xs"
        value={edge.kind}
        onChange={(e) => campusStore.updateEdge(edge.from, edge.to, { kind: e.target.value as CampusEdge["kind"] })}
      >
        <option value="walk">Walk</option>
        <option value="stair">Stairs</option>
        <option value="lift">Lift</option>
      </select>
      <Input
        type="number"
        className="h-8 w-20"
        defaultValue={edge.weight}
        onBlur={(e) => campusStore.updateEdge(edge.from, edge.to, { weight: Number(e.target.value) })}
        aria-label="Distance in meters"
      />
      <label className="flex items-center gap-1 text-xs text-muted-foreground">
        <Switch checked={!!edge.accessible} onCheckedChange={(v) => campusStore.updateEdge(edge.from, edge.to, { accessible: v })} />
        ♿
      </label>
      <Button size="sm" variant="outline" className="h-8 text-xs" onClick={() => campusStore.toggleEdgeBlocked(edge.from, edge.to)}>
        {edge.blocked ? "Unavailable" : "Available"}
      </Button>
      <Button size="sm" variant="ghost" className="h-8" aria-label="Delete connection" onClick={() => campusStore.removeEdge(edge.from, edge.to)}>
        <Unlink className="h-4 w-4" />
      </Button>
    </div>
  );
}

/** Connect a staircase or lift on one floor to the matching node on another. */
function FloorLinker() {
  const { nodes, edges, floors } = useCampus();
  const verticals = nodes.filter((n) => n.type === "stair" || n.type === "lift");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [kind, setKind] = useState<"stair" | "lift">("stair");
  const [weight, setWeight] = useState(6);
  const nodeMap = new Map(nodes.map((n) => [n.id, n]));
  const floorName = (id: FloorId) => floors.find((f) => f.id === id)?.name ?? `Floor ${id}`;
  const crossEdges = edges.filter((e) => {
    const a = nodeMap.get(e.from);
    const b = nodeMap.get(e.to);
    return a && b && a.floor !== b.floor;
  });

  return (
    <section className="rounded-2xl border border-border/60 bg-card p-5">
      <h3 className="font-semibold">Multi-floor connections (staircases & lifts)</h3>
      <p className="mt-1 text-sm text-muted-foreground">
        Link vertical checkpoints so A* can route between floors, e.g. Staircase 1 (Ground) ↕ Staircase 1 (First).
      </p>
      <div className="mt-4 flex flex-wrap items-end gap-3">
        <VerticalSelect label="From" value={from} onChange={setFrom} nodes={verticals} floorName={floorName} />
        <VerticalSelect label="To" value={to} onChange={setTo} nodes={verticals} floorName={floorName} />
        <div>
          <Label className="mb-1.5 block text-xs text-muted-foreground">Kind</Label>
          <select className="h-9 rounded-md border border-input bg-background px-2 text-sm" value={kind} onChange={(e) => setKind(e.target.value as "stair" | "lift")}>
            <option value="stair">Staircase</option>
            <option value="lift">Lift</option>
          </select>
        </div>
        <div>
          <Label className="mb-1.5 block text-xs text-muted-foreground">Weight</Label>
          <Input type="number" className="h-9 w-24" value={weight} onChange={(e) => setWeight(Number(e.target.value))} />
        </div>
        <Button
          size="sm"
          onClick={() => {
            if (!from || !to || from === to) return;
            campusStore.addEdge({ from, to, weight, kind, accessible: kind === "lift" });
            setFrom("");
            setTo("");
          }}
        >
          <Link2 className="mr-2 h-4 w-4" /> Connect floors
        </Button>
      </div>

      <div className="mt-4 divide-y divide-border/60 rounded-xl border border-border/60">
        {crossEdges.map((e, i) => (
          <EdgeRow
            key={i}
            edge={e}
            label={`${nodeMap.get(e.from)?.label} (${floorName(nodeMap.get(e.from)!.floor)}) ↕ ${nodeMap.get(e.to)?.label} (${floorName(nodeMap.get(e.to)!.floor)})`}
          />
        ))}
        {crossEdges.length === 0 && (
          <div className="px-4 py-6 text-center text-sm text-muted-foreground">No floor-to-floor links yet.</div>
        )}
      </div>
    </section>
  );
}

function VerticalSelect({
  label,
  value,
  onChange,
  nodes,
  floorName,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  nodes: CampusNode[];
  floorName: (id: FloorId) => string;
}) {
  return (
    <div>
      <Label className="mb-1.5 block text-xs text-muted-foreground">{label}</Label>
      <select className="h-9 min-w-[12rem] rounded-md border border-input bg-background px-2 text-sm" value={value} onChange={(e) => onChange(e.target.value)}>
        <option value="">Select…</option>
        {nodes.map((n) => (
          <option key={n.id} value={n.id}>
            {n.label} — {floorName(n.floor)}
          </option>
        ))}
      </select>
    </div>
  );
}
