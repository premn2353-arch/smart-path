import { useRef, useState } from "react";
import { Building2, ImageUp, Layers, Plus, Trash2, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { campusStore, useCampus } from "@/lib/campus/store";
import { fileToPlanImage } from "@/lib/campus/image";
import type { Building, Floor } from "@/lib/campus/model";

const slugify = (s: string) =>
  s.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "floor";

/** Admin "Campus Map Management": buildings, floors and floor-plan images. */
export function FloorPlanManager() {
  const { buildings, floors, nodes } = useCampus();
  const [b, setB] = useState({ name: "", description: "" });
  const [f, setF] = useState({ name: "", level: "", buildingId: buildings[0]?.id ?? "" });

  return (
    <div className="space-y-8">
      {/* Buildings */}
      <section className="rounded-2xl border border-border/60 bg-card p-5">
        <h2 className="flex items-center gap-2 text-lg font-semibold">
          <Building2 className="h-4 w-4 text-primary" /> Buildings
        </h2>
        <div className="mt-4 space-y-3">
          {buildings.map((bl: Building) => (
            <div key={bl.id} className="flex flex-wrap items-center gap-2">
              <Input
                className="h-9 max-w-xs"
                defaultValue={bl.name}
                onBlur={(e) => campusStore.updateBuilding(bl.id, { name: e.target.value })}
              />
              <Input
                className="h-9 flex-1 min-w-[12rem]"
                defaultValue={bl.description ?? ""}
                placeholder="Description"
                onBlur={(e) => campusStore.updateBuilding(bl.id, { description: e.target.value })}
              />
              <code className="text-xs text-muted-foreground">{bl.id}</code>
              <Button
                size="sm"
                variant="ghost"
                aria-label={`Delete ${bl.name}`}
                onClick={() => {
                  if (confirm(`Delete building "${bl.name}"?`)) campusStore.removeBuilding(bl.id);
                }}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          ))}
        </div>
        <form
          className="mt-4 flex flex-wrap items-end gap-3 border-t border-border/60 pt-4"
          onSubmit={(e) => {
            e.preventDefault();
            if (!b.name.trim()) return;
            campusStore.addBuilding({
              id: slugify(b.name),
              name: b.name.trim(),
              campusId: "campus-main",
              description: b.description || undefined,
            });
            setB({ name: "", description: "" });
          }}
        >
          <div>
            <Label className="mb-1.5 block text-xs text-muted-foreground">Building name</Label>
            <Input value={b.name} onChange={(e) => setB({ ...b, name: e.target.value })} placeholder="Science Block" className="h-9" />
          </div>
          <div className="flex-1 min-w-[12rem]">
            <Label className="mb-1.5 block text-xs text-muted-foreground">Description</Label>
            <Input value={b.description} onChange={(e) => setB({ ...b, description: e.target.value })} className="h-9" />
          </div>
          <Button type="submit" size="sm"><Plus className="mr-2 h-4 w-4" /> Add building</Button>
        </form>
      </section>

      {/* Floors */}
      <section className="rounded-2xl border border-border/60 bg-card p-5">
        <h2 className="flex items-center gap-2 text-lg font-semibold">
          <Layers className="h-4 w-4 text-primary" /> Floors & floor plans
        </h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Upload a real floor-plan image per floor. Locations use 0–100 coordinates, so plans can be
          replaced any time without moving the markers.
        </p>

        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          {floors.map((fl: Floor) => (
            <FloorCard key={fl.id} floor={fl} count={nodes.filter((n) => n.floor === fl.id).length} />
          ))}
        </div>

        <form
          className="mt-6 flex flex-wrap items-end gap-3 border-t border-border/60 pt-4"
          onSubmit={(e) => {
            e.preventDefault();
            const level = Number(f.level);
            if (!f.name.trim() || Number.isNaN(level)) return;
            if (floors.some((x) => x.id === level)) {
              alert(`Floor number ${level} already exists.`);
              return;
            }
            campusStore.addFloor({
              id: level,
              name: f.name.trim(),
              slug: slugify(f.name),
              level,
              buildingId: f.buildingId || undefined,
            });
            setF({ name: "", level: "", buildingId: f.buildingId });
          }}
        >
          <div>
            <Label className="mb-1.5 block text-xs text-muted-foreground">Floor name</Label>
            <Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} placeholder="Third Floor" className="h-9" />
          </div>
          <div>
            <Label className="mb-1.5 block text-xs text-muted-foreground">Floor number</Label>
            <Input type="number" value={f.level} onChange={(e) => setF({ ...f, level: e.target.value })} placeholder="3" className="h-9 w-28" />
          </div>
          <div>
            <Label className="mb-1.5 block text-xs text-muted-foreground">Building</Label>
            <select
              className="h-9 rounded-md border border-input bg-background px-3 text-sm"
              value={f.buildingId}
              onChange={(e) => setF({ ...f, buildingId: e.target.value })}
            >
              <option value="">—</option>
              {buildings.map((bl) => (
                <option key={bl.id} value={bl.id}>{bl.name}</option>
              ))}
            </select>
          </div>
          <Button type="submit" size="sm"><Plus className="mr-2 h-4 w-4" /> Add floor</Button>
        </form>
      </section>
    </div>
  );
}

function FloorCard({ floor, count }: { floor: Floor; count: number }) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function onFile(file: File | undefined) {
    if (!file) return;
    setBusy(true);
    setError(null);
    try {
      const plan = await fileToPlanImage(file);
      campusStore.setFloorPlan(floor.id, plan.dataUrl);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Upload failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="rounded-2xl border border-border/60 bg-background p-4">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <Input
            className="h-9 font-medium"
            defaultValue={floor.name}
            onBlur={(e) => campusStore.updateFloor(floor.id, { name: e.target.value })}
          />
          <div className="mt-1 text-xs text-muted-foreground">
            Floor {floor.level} · /map/{floor.slug} · {count} locations
          </div>
        </div>
        <Button
          size="sm"
          variant="ghost"
          aria-label={`Delete ${floor.name}`}
          onClick={() => {
            if (confirm(`Delete "${floor.name}" and all of its locations?`)) campusStore.removeFloor(floor.id);
          }}
        >
          <Trash2 className="h-4 w-4" />
        </Button>
      </div>

      <div className="mt-3 aspect-video overflow-hidden rounded-xl border border-border/60 bg-muted">
        {floor.planImage ? (
          <img src={floor.planImage} alt={`${floor.name} plan`} className="h-full w-full object-contain" />
        ) : (
          <div className="flex h-full items-center justify-center text-xs text-muted-foreground">
            No floor plan uploaded
          </div>
        )}
      </div>

      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => onFile(e.target.files?.[0])}
      />
      <div className="mt-3 flex flex-wrap gap-2">
        <Button size="sm" variant="outline" disabled={busy} onClick={() => inputRef.current?.click()}>
          {floor.planImage ? <ImageUp className="mr-2 h-4 w-4" /> : <Upload className="mr-2 h-4 w-4" />}
          {busy ? "Uploading…" : floor.planImage ? "Replace plan" : "Upload plan"}
        </Button>
        {floor.planImage && (
          <Button size="sm" variant="ghost" onClick={() => campusStore.setFloorPlan(floor.id, undefined)}>
            Delete plan
          </Button>
        )}
      </div>
      {error && <p className="mt-2 text-xs text-destructive">{error}</p>}
    </div>
  );
}
