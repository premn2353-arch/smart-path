import { useEffect, useMemo, useState } from "react";
import QRCode from "qrcode";
import { Download, QrCode as QrIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { campusStore, useCampus } from "@/lib/campus/store";
import type { CampusNode } from "@/lib/campus/model";

export const qrPayload = (id: string) => `SMARTPATH:${id}`;

function QrTile({ node }: { node: CampusNode }) {
  const [src, setSrc] = useState<string | null>(null);
  useEffect(() => {
    QRCode.toDataURL(qrPayload(node.id), { margin: 1, width: 480 })
      .then(setSrc)
      .catch(() => setSrc(null));
  }, [node.id]);

  return (
    <div className="rounded-2xl border border-border/60 bg-card p-4 text-center">
      <div className="flex items-center justify-center rounded-xl bg-white p-3">
        {src ? (
          <img src={src} alt={`QR code for ${node.label}`} className="h-40 w-40" />
        ) : (
          <div className="h-40 w-40 animate-pulse rounded bg-muted" />
        )}
      </div>
      <div className="mt-3 truncate font-semibold">{node.label}</div>
      <code className="block truncate text-xs text-muted-foreground">{qrPayload(node.id)}</code>
      <div className="mt-3 flex items-center justify-between gap-2">
        <label className="flex items-center gap-2 text-xs text-muted-foreground">
          <Switch
            checked={!!node.hasQr}
            onCheckedChange={(v) => campusStore.updateNode(node.id, { hasQr: v })}
          />
          Assigned
        </label>
        <div className="flex gap-1">
          <Button
            size="sm"
            variant="outline"
            disabled={!src}
            onClick={() => {
              if (!src) return;
              const a = document.createElement("a");
              a.href = src;
              a.download = `qr-${node.id}.png`;
              a.click();
            }}
          >
            <Download className="mr-1.5 h-3.5 w-3.5" /> PNG
          </Button>
          <Button
            size="sm"
            variant="ghost"
            disabled={!src}
            onClick={() => {
              if (!src) return;
              const w = window.open("", "_blank");
              if (!w) return;
              w.document.write(
                `<title>${node.label} QR</title><body style="font-family:sans-serif;text-align:center;padding:40px"><img src="${src}" style="width:340px"/><h2>${node.label}</h2><code>${qrPayload(node.id)}</code></body>`,
              );
              w.document.close();
              w.print();
            }}
          >
            Print
          </Button>
        </div>
      </div>
    </div>
  );
}

/** Admin QR checkpoint management: create, view, download and print codes. */
export function QrManager() {
  const { nodes, floors } = useCampus();
  const [q, setQ] = useState("");
  const [onlyAssigned, setOnlyAssigned] = useState(false);

  const list = useMemo(() => {
    const t = q.trim().toLowerCase();
    return nodes.filter((n) => {
      if (onlyAssigned && !n.hasQr) return false;
      if (!t) return true;
      return n.label.toLowerCase().includes(t) || n.id.toLowerCase().includes(t);
    });
  }, [nodes, q, onlyAssigned]);

  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-border/60 bg-card p-4">
        <h2 className="flex items-center gap-2 font-semibold">
          <QrIcon className="h-4 w-4 text-primary" /> QR checkpoints
        </h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Every location can carry a printed QR checkpoint. Scanning it sets the user's current
          indoor location and starts navigation from there.
        </p>
        <div className="mt-3 flex flex-wrap items-center gap-3">
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search locations…"
            className="h-9 max-w-xs"
            aria-label="Search locations"
          />
          <label className="flex items-center gap-2 text-sm text-muted-foreground">
            <Switch checked={onlyAssigned} onCheckedChange={setOnlyAssigned} />
            Only assigned checkpoints
          </label>
        </div>
      </div>

      {floors.map((f) => {
        const forFloor = list.filter((n) => n.floor === f.id);
        if (forFloor.length === 0) return null;
        return (
          <section key={f.id}>
            <h3 className="mb-3 mt-6 text-sm font-semibold uppercase tracking-wide text-muted-foreground">
              {f.name}
            </h3>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {forFloor.map((n) => (
                <QrTile key={n.id} node={n} />
              ))}
            </div>
          </section>
        );
      })}
    </div>
  );
}
