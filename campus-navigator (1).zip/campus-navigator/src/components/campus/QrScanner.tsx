import { useCallback, useEffect, useRef, useState } from "react";
import { Camera, CameraOff, ExternalLink, RefreshCw, ShieldAlert } from "lucide-react";
import { Button } from "@/components/ui/button";

interface Props {
  onDecoded: (text: string) => void;
  /** Try to start the camera as soon as the component mounts. */
  autoStart?: boolean;
}

type Status = "idle" | "starting" | "scanning" | "error" | "stopped";

const ELEMENT_ID = "campus-qr-reader";

export function QrScanner({ onDecoded, autoStart = true }: Props) {
  const scannerRef = useRef<any>(null);
  const decodedRef = useRef(false);
  const [status, setStatus] = useState<Status>("idle");
  const [error, setError] = useState<string | null>(null);

  const stop = useCallback(async () => {
    const inst = scannerRef.current;
    scannerRef.current = null;
    if (!inst) return;
    try {
      if (inst.isScanning) await inst.stop();
      inst.clear();
    } catch {
      /* ignore */
    }
  }, []);

  const start = useCallback(async () => {
    if (scannerRef.current) return;
    setError(null);
    setStatus("starting");
    decodedRef.current = false;
    try {
      const { Html5Qrcode } = await import("html5-qrcode");
      const instance = new Html5Qrcode(ELEMENT_ID, { verbose: false });
      scannerRef.current = instance;

      const onSuccess = async (text: string) => {
        if (decodedRef.current) return;
        decodedRef.current = true;
        await stop();
        setStatus("stopped");
        onDecoded(text);
      };

      const config = {
        fps: 10,
        qrbox: (vw: number, vh: number) => {
          const size = Math.floor(Math.min(vw, vh) * 0.75);
          return { width: size, height: size };
        },
        aspectRatio: 1,
      };

      // Try rear camera first, then any camera (desktop webcams reject "environment").
      const attempts: any[] = [
        { facingMode: { exact: "environment" } },
        { facingMode: "environment" },
        { facingMode: "user" },
      ];
      try {
        const cams = await (await import("html5-qrcode")).Html5Qrcode.getCameras();
        if (cams?.length) attempts.push({ deviceId: { exact: cams[cams.length - 1].id } });
      } catch {
        /* enumeration may fail before permission is granted */
      }

      let lastErr: any = null;
      let started = false;
      for (const cam of attempts) {
        try {
          await instance.start(cam, config, onSuccess, () => {});
          started = true;
          break;
        } catch (e) {
          lastErr = e;
        }
      }
      if (!started) throw lastErr ?? new Error("Unable to start the camera.");
      setStatus("scanning");
    } catch (e: any) {
      scannerRef.current = null;
      const name = e?.name || "";
      const msg = String(e?.message || e || "");
      const insecure = typeof window !== "undefined" && !window.isSecureContext;
      const blockedByFrame =
        /permissions policy|permission policy|disallowed by/i.test(msg) ||
        (name === "NotAllowedError" && typeof window !== "undefined" && window.self !== window.top);

      if (insecure) {
        setError("Camera access requires a secure (HTTPS) connection. Open this page over HTTPS and try again.");
      } else if (blockedByFrame) {
        setError(
          "The camera is blocked inside this embedded preview. Open the app in its own browser tab (or on your phone) and try again — manual entry and the demo QR still work here.",
        );
      } else if (name === "NotAllowedError" || /permission|denied/i.test(msg)) {
        setError("Camera permission denied. Please allow camera access in your browser settings, then tap Scan Again.");
      } else if (name === "NotFoundError" || name === "OverconstrainedError" || /no camera|not found|requested device/i.test(msg)) {
        setError("No usable camera was found on this device. Use manual entry or the demo QR instead.");
      } else if (name === "NotReadableError") {
        setError("The camera is already in use by another app or tab. Close it and tap Scan Again.");
      } else {
        setError(msg || "Unable to start the camera.");
      }
      setStatus("error");
    }
  }, [onDecoded, stop]);


  useEffect(() => {
    if (autoStart) void start();
    return () => {
      void stop();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="space-y-3">
      <div className="relative aspect-square overflow-hidden rounded-2xl border border-border/60 bg-black">
        <div id={ELEMENT_ID} className="h-full w-full [&_video]:h-full [&_video]:w-full [&_video]:object-cover" />
        {status !== "scanning" && (
          <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center gap-2 bg-muted text-muted-foreground">
            {status === "error" ? <ShieldAlert className="h-10 w-10" /> : <Camera className="h-10 w-10" />}
            <p className="px-6 text-center text-sm">
              {status === "starting"
                ? "Requesting camera access…"
                : status === "error"
                  ? "Camera unavailable"
                  : "Camera preview"}
            </p>
          </div>
        )}
      </div>

      {error && (
        <div className="space-y-2">
          <p className="text-sm text-destructive">{error}</p>
          <Button
            variant="outline"
            size="sm"
            className="w-full"
            onClick={() => window.open(window.location.href, "_blank", "noopener")}
          >
            <ExternalLink className="mr-2 h-4 w-4" /> Open scanner in a new tab
          </Button>
        </div>
      )}

      {status === "scanning" ? (
        <Button
          className="w-full"
          variant="outline"
          onClick={() => {
            void stop().then(() => setStatus("stopped"));
          }}
        >
          <CameraOff className="mr-2 h-4 w-4" /> Stop camera
        </Button>
      ) : (
        <Button className="w-full" onClick={() => void start()} disabled={status === "starting"}>
          {status === "idle" ? <Camera className="mr-2 h-4 w-4" /> : <RefreshCw className="mr-2 h-4 w-4" />}
          {status === "idle" ? "Start camera" : "Scan Again"}
        </Button>
      )}
    </div>
  );
}
