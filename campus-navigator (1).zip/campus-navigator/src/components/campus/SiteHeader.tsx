import { Link } from "@tanstack/react-router";
import { Compass } from "lucide-react";

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-border/60 bg-background/80 backdrop-blur">
      <div className="mx-auto flex h-14 max-w-6xl items-center gap-3 px-4">
        <Link to="/" className="flex shrink-0 items-center gap-2 font-semibold">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <Compass className="h-4 w-4" />
          </span>
          <span className="hidden sm:inline">Smart Path</span>
        </Link>
        <nav className="-mx-1 flex flex-1 items-center gap-1 overflow-x-auto whitespace-nowrap px-1 text-sm [scrollbar-width:none] [&::-webkit-scrollbar]:hidden sm:justify-end">
          {[
            { label: "Scan", to: "/scan" },
            { label: "Destinations", to: "/destinations" },
            { label: "Shortest Path", to: "/shortest-path" },
            { label: "Indoor", to: "/indoor" },
            { label: "Occupancy", to: "/occupancy" },
            { label: "Admin", to: "/admin" },
          ].map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className="rounded-md px-3 py-1.5 text-muted-foreground transition hover:bg-muted hover:text-foreground [&.active]:bg-muted [&.active]:text-foreground"
            >
              {item.label}
            </Link>
          ))}
          <Link
            to="/map/$floor"
            params={{ floor: "ground" }}
            className="rounded-md px-3 py-1.5 text-muted-foreground transition hover:bg-muted hover:text-foreground [&.active]:bg-muted [&.active]:text-foreground"
          >
            Map
          </Link>
          <Link
            to="/emergency"
            search={{ from: "gate" }}
            className="rounded-md px-3 py-1.5 font-medium text-destructive transition hover:bg-destructive/10 [&.active]:bg-destructive/10"
          >
            Emergency
          </Link>
        </nav>
      </div>
    </header>

  );
}
