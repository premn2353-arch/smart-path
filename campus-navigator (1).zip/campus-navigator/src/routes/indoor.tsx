import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Building2, Clock, Navigation2, Ruler } from "lucide-react";
import { SiteHeader } from "@/components/campus/SiteHeader";
import { IndoorMapView } from "@/components/campus/IndoorMapView";
import { Button } from "@/components/ui/button";
import { useCampus, useCurrentLocation } from "@/lib/campus/store";
import { resolveRoute } from "@/lib/campus/navigation";

export const Route = createFileRoute("/indoor")({
  head: () => ({
    meta: [
      { title: "Indoor Navigation — Smart Path Campus" },
      {
        name: "description",
        content:
          "Select a building, floor and room to get an indoor walking route from your current location.",
      },
      { property: "og:title", content: "Indoor Navigation — Smart Path Campus" },
      {
        property: "og:description",
        content: "Building, floor and room picker with a live indoor route on the floor plan.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: IndoorPage,
});

const selectClass =
  "w-full rounded-lg border border-border/60 bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring";

function IndoorPage() {
  const { nodes, edges, floors, buildings } = useCampus();
  const current = useCurrentLocation();

  const [buildingId, setBuildingId] = useState(buildings[0]?.id ?? "");
  const floorsInBuilding = useMemo(
    () => floors.filter((f) => !f.buildingId || f.buildingId === buildingId),
    [floors, buildingId],
  );
  const [floorId, setFloorId] = useState<number | null>(null);
  const activeFloor = floorId ?? floorsInBuilding[0]?.id ?? floors[0]?.id ?? 0;

  const rooms = useMemo(
    () =>
      nodes
        .filter((n) => n.floor === activeFloor)
        .filter((n) => !buildingId || !n.buildingId || n.buildingId === buildingId)
        .filter((n) => n.isDestination || ["room", "lab", "department", "landmark"].includes(n.type))
        .sort((a, b) => a.label.localeCompare(b.label)),
    [nodes, activeFloor, buildingId],
  );

  const [roomId, setRoomId] = useState<string>("");
  const destination = rooms.find((r) => r.id === roomId) ?? rooms[0];

  const startId = current?.id ?? "gate";
  const plan = useMemo(
    () =>
      destination && destination.id !== startId
        ? resolveRoute(nodes, edges, startId, destination.id, "shortest")
        : null,
    [nodes, edges, startId, destination],
  );

  const mapFloor = plan ? activeFloor : activeFloor;

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main className="mx-auto max-w-6xl px-4 py-6 sm:py-10">
        <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">Indoor navigation</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Starting from{" "}
          <strong className="text-foreground">{current?.label ?? "Main Gate"}</strong>
          {!current ? " — scan a QR checkpoint to set your real position." : ""}
        </p>

        <div className="mt-6 grid gap-3 rounded-2xl border border-border/60 bg-card p-4 sm:grid-cols-3">
          <label className="block text-sm">
            <span className="mb-1 block text-muted-foreground">Building</span>
            <select
              className={selectClass}
              value={buildingId}
              onChange={(e) => {
                setBuildingId(e.target.value);
                setFloorId(null);
                setRoomId("");
              }}
            >
              {buildings.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.name}
                </option>
              ))}
            </select>
          </label>
          <label className="block text-sm">
            <span className="mb-1 block text-muted-foreground">Floor</span>
            <select
              className={selectClass}
              value={String(activeFloor)}
              onChange={(e) => {
                setFloorId(Number(e.target.value));
                setRoomId("");
              }}
            >
              {floorsInBuilding.map((f) => (
                <option key={f.id} value={f.id}>
                  {f.name}
                </option>
              ))}
            </select>
          </label>
          <label className="block text-sm">
            <span className="mb-1 block text-muted-foreground">Room</span>
            <select
              className={selectClass}
              value={destination?.id ?? ""}
              onChange={(e) => setRoomId(e.target.value)}
            >
              {rooms.length === 0 ? <option value="">No rooms on this floor</option> : null}
              {rooms.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.label}
                </option>
              ))}
            </select>
          </label>
        </div>

        <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_340px]">
          <div className="rounded-2xl border border-border/60 bg-card p-3">
            <div className="mb-3 flex items-center gap-2 text-sm font-medium">
              <Building2 className="h-4 w-4 text-primary" />
              {floors.find((f) => f.id === mapFloor)?.name}
            </div>
            <IndoorMapView
              nodes={nodes}
              edges={edges}
              floor={mapFloor}
              planImage={floors.find((f) => f.id === mapFloor)?.planImage}
              pathNodeIds={plan?.path.nodes ?? []}
              startId={startId}
              endId={destination?.id}
              currentId={current?.id}
              onSelectNode={(n) => {
                if (n.floor === mapFloor) setRoomId(n.id);
              }}
            />
          </div>

          <aside className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-2xl border border-border/60 bg-card p-3">
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <Ruler className="h-3.5 w-3.5" /> Distance
                </div>
                <div className="mt-1 text-lg font-semibold">
                  {plan ? `${Math.round(plan.path.distance)} m` : "—"}
                </div>
              </div>
              <div className="rounded-2xl border border-border/60 bg-card p-3">
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <Clock className="h-3.5 w-3.5" /> Walk time
                </div>
                <div className="mt-1 text-lg font-semibold">
                  {plan ? `${plan.path.minutes} min` : "—"}
                </div>
              </div>
            </div>

            <div className="rounded-2xl border border-border/60 bg-card">
              <div className="border-b border-border/60 px-4 py-3 text-sm font-semibold">
                Indoor directions
              </div>
              {plan ? (
                <ol className="max-h-[420px] overflow-auto p-2">
                  {plan.path.steps.map((s, i) => (
                    <li key={i} className="flex gap-3 rounded-lg p-2 text-sm">
                      <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-semibold text-primary">
                        {i + 1}
                      </span>
                      <div>
                        <div className="font-medium">{s.instruction}</div>
                        <div className="text-xs text-muted-foreground">
                          Floor {s.to.floor} · {s.kind}
                        </div>
                      </div>
                    </li>
                  ))}
                </ol>
              ) : (
                <div className="p-6 text-center text-sm text-muted-foreground">
                  Select a room to see the indoor route.
                </div>
              )}
            </div>

            {plan ? (
              <Button asChild className="w-full">
                <Link
                  to="/navigate"
                  search={{ from: startId, to: plan.end.id, mode: "shortest" }}
                >
                  <Navigation2 className="mr-2 h-4 w-4" />
                  Start turn-by-turn
                </Link>
              </Button>
            ) : null}
          </aside>
        </div>
      </main>
    </div>
  );
}
