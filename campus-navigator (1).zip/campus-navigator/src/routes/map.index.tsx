import { createFileRoute, Link, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/map/")({
  beforeLoad: () => {
    throw redirect({ to: "/map/$floor", params: { floor: "ground" } });
  },
  component: () => <Link to="/map/$floor" params={{ floor: "ground" }}>Open campus map</Link>,
});
