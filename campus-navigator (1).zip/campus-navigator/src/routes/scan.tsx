import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { AlertCircle, CheckCircle2, DoorOpen, MapPin, QrCode } from "lucide-react";
import { useEffect, useState } from "react";
import QRCode from "qrcode";
import { SiteHeader } from "@/components/campus/SiteHeader";
import { QrScanner } from "@/components/campus/QrScanner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { currentLocationStore, useCampus } from "@/lib/campus/store";
import { occupancyStore, trackedIdsForNode } from "@/lib/campus/occupancy-store";

// Payload format for campus QR codes: SMARTPATH:<nodeId>
const QR_PREFIX = "SMARTPATH:";
const DEMO_PAYLOAD = `${QR_PREFIX}gate`;

export const Route = createFileRoute("/scan")({
  head: () => ({
    meta: [
      { title: "Scan QR Code — Smart Path Navigation" },
      { name: "description", content: "Scan the QR code at the main gate to start indoor navigation on campus." },
      { property: "og:title", content: "Scan QR Code — Smart Path Navigation" },
      { property: "og:description", content: "Scan at the main gate to begin campus wayfinding." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ScanPage,
});

function parseQr(text: string, validIds: Set<string>): string | null {
  const raw = text.trim();
  const id = raw.startsWith(QR_PREFIX) ? raw.slice(QR_PREFIX.length) : raw;
  return validIds.has(id) ? id : null;
}

function ScanPage() {
  const navigate = useNavigate();
  const { nodes } = useCampus();
  const [demoQr, setDemoQr] = useState<string | null>(null);
  const [detected, setDetected] = useState<{ id: string; label: string; trackedIds: string[] } | null>(null);
  const [checkedIn, setCheckedIn] = useState(false);
  const [invalid, setInvalid] = useState<string | null>(null);
  const [manual, setManual] = useState("");

  useEffect(() => {
    QRCode.toDataURL(DEMO_PAYLOAD, { margin: 1, width: 240 }).then(setDemoQr).catch(() => {});
  }, []);

  useEffect(() => {
    if (!detected) return;
    const t = setTimeout(() => {
      navigate({ to: "/destinations", search: { from: detected.id } });
    }, 1600);
    return () => clearTimeout(t);
  }, [detected, navigate]);

  const handleDecoded = (text: string) => {
    const ids = new Set(nodes.map((n) => n.id));
    const id = parseQr(text, ids);
    if (!id) {
      setInvalid(`Unrecognised QR code: "${text.slice(0, 60)}". Try scanning again.`);
      return;
    }
    const node = nodes.find((n) => n.id === id)!;
    setInvalid(null);
    setDetected({ id: node.id, label: node.label, trackedIds: trackedIdsForNode(node.id, node.floor) });
    setCheckedIn(false);
    currentLocationStore.set(node.id);
  };

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main className="mx-auto max-w-3xl px-4 py-8">
        <h1 className="text-3xl font-bold tracking-tight">Scan QR Code</h1>
        <p className="mt-2 text-muted-foreground">
          Point your camera at the QR code posted at the main gate. Your starting location will be
          detected automatically.
        </p>

        {detected && (
          <div className="mt-6 flex items-center gap-3 rounded-2xl border border-primary/40 bg-primary/10 p-4 text-primary">
            <CheckCircle2 className="h-6 w-6" />
            <div>
              <div className="font-semibold">QR Code Scanned Successfully</div>
              <div className="text-sm">Starting Location: {detected.label}</div>
              <div className="text-xs opacity-80">Redirecting to destination selection…</div>
              {detected.trackedIds.length > 0 && (
                <Button
                  size="sm"
                  variant={checkedIn ? "secondary" : "default"}
                  className="mt-2"
                  onClick={() => {
                    if (checkedIn) occupancyStore.checkOut(detected.trackedIds);
                    else occupancyStore.checkIn(detected.trackedIds);
                    setCheckedIn(!checkedIn);
                  }}
                >
                  {checkedIn ? "Check out" : "Check in here"}
                </Button>
              )}
            </div>
          </div>
        )}

        {invalid && !detected && (
          <div className="mt-6 flex items-center gap-3 rounded-2xl border border-destructive/40 bg-destructive/10 p-4 text-destructive">
            <AlertCircle className="h-5 w-5 shrink-0" />
            <p className="text-sm">{invalid}</p>
          </div>
        )}

        <div className="mt-6 grid gap-6 sm:grid-cols-2">
          <div>
            <h2 className="mb-2 text-sm font-semibold text-muted-foreground">Camera scanner</h2>
            <QrScanner onDecoded={handleDecoded} />
          </div>

          <div className="space-y-4">
            <div className="rounded-2xl border border-border/60 bg-card p-4">
              <h2 className="text-sm font-semibold text-muted-foreground">Demo QR — Main Gate</h2>
              <p className="mt-1 text-xs text-muted-foreground">
                No printed code nearby? Scan this from another device to test the flow.
              </p>
              <div className="mt-3 flex items-center justify-center rounded-xl bg-white p-3">
                {demoQr ? (
                  <img src={demoQr} alt="Demo Main Gate QR code" className="h-40 w-40" />
                ) : (
                  <div className="h-40 w-40 animate-pulse rounded bg-muted" />
                )}
              </div>
              <Button
                variant="secondary"
                className="mt-3 w-full"
                onClick={() => handleDecoded(DEMO_PAYLOAD)}
              >
                Use demo Main Gate
              </Button>
              <Button asChild variant="ghost" className="mt-2 w-full">
                <Link to="/qr-demo">
                  <QrCode className="mr-2 h-4 w-4" /> Open printable demo QR page
                </Link>
              </Button>
            </div>

            <div className="rounded-2xl border border-border/60 bg-card p-4">
              <h2 className="text-sm font-semibold text-muted-foreground">Enter QR Code Data Manually</h2>
              <form
                className="mt-3 flex gap-2"
                onSubmit={(e) => {
                  e.preventDefault();
                  if (manual.trim()) handleDecoded(manual);
                }}
              >
                <Input
                  value={manual}
                  onChange={(e) => setManual(e.target.value)}
                  placeholder="SMARTPATH:gate"
                  aria-label="QR code data"
                />
                <Button type="submit">Use</Button>
              </form>
            </div>

            <div className="rounded-2xl border border-border/60 bg-card p-4">
              <h2 className="text-sm font-semibold text-muted-foreground">Camera unavailable?</h2>
              <p className="mt-1 text-xs text-muted-foreground">
                Choose your starting point without scanning.
              </p>
              <Button asChild variant="outline" className="mt-3 w-full">
                <Link to="/destinations" search={{ from: "gate" }}>
                  <DoorOpen className="mr-2 h-4 w-4" />
                  Select Starting Location Manually
                </Link>
              </Button>
            </div>

            <div className="flex items-start gap-2 rounded-xl bg-muted/60 p-3 text-xs text-muted-foreground">
              <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
              QR payload format: <code className="ml-1">SMARTPATH:&lt;locationId&gt;</code>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
