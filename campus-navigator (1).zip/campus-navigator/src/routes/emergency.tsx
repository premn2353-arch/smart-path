import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { z } from "zod";
import { AlertTriangle, Building, DoorOpen, Phone, ShieldAlert, Ambulance, Flame, Siren } from "lucide-react";
import { SiteHeader } from "@/components/campus/SiteHeader";
import { CampusMap } from "@/components/campus/CampusMap";
import { Button } from "@/components/ui/button";
import { useCampus } from "@/lib/campus/store";
import { type FloorId } from "@/lib/campus/data";
import { nearestEmergencyExit } from "@/lib/campus/graph";

const CONTACTS = [
  { name: "Campus Security", number: "+911234567890", display: "+91 12345 67890", icon: ShieldAlert, note: "24/7 control room" },
  { name: "Ambulance", number: "108", display: "108", icon: Ambulance, note: "Medical emergency" },
  { name: "Police", number: "100", display: "100", icon: Siren, note: "Police control room" },
  { name: "Fire & Rescue", number: "101", display: "101", icon: Flame, note: "Fire emergency" },
];

const searchSchema = z.object({ from: z.string().default("gate") });


export const Route = createFileRoute("/emergency")({
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: "Emergency Exit — Smart Path Navigation" },
      { name: "description", content: "Find the nearest emergency exit from your current location on campus." },
      { property: "og:title", content: "Emergency Exit — Smart Path Navigation" },
      { property: "og:description", content: "Fastest route to the nearest emergency exit." },
    ],
  }),
  component: EmergencyPage,
});

function EmergencyPage() {
  const { from } = Route.useSearch();
  const { nodes, edges, floors } = useCampus();
  const start = nodes.find((n) => n.id === from);

  const result = useMemo(() => nearestEmergencyExit(nodes, edges, from), [nodes, edges, from]);
  const exit = result ? nodes.find((n) => n.id === result.exitId) : undefined;

  const [floor, setFloor] = useState<FloorId>(start?.floor ?? 0);

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main className="mx-auto max-w-6xl px-4 py-6 sm:py-8">
        <div className="flex items-start gap-3 rounded-2xl border border-destructive/40 bg-destructive/10 px-4 py-3 text-destructive">
          <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0" />
          <div className="text-sm font-medium">
            Emergency route from <strong>{start?.label ?? from}</strong>
            {exit ? (
              <>
                {" "}to <strong>{exit.label}</strong> · {result?.path.distance} m
              </>
            ) : null}
          </div>
        </div>

        <section className="mt-6">
          <h2 className="text-lg font-semibold">Emergency contacts</h2>
          <div className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {CONTACTS.map((c) => (
              <div key={c.name} className="rounded-2xl border border-border/60 bg-card p-4">
                <div className="flex items-center gap-2">
                  <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-destructive/10 text-destructive">
                    <c.icon className="h-4 w-4" />
                  </span>
                  <div className="min-w-0">
                    <div className="truncate text-sm font-semibold">{c.name}</div>
                    <div className="truncate text-xs text-muted-foreground">{c.note}</div>
                  </div>
                </div>
                <Button asChild variant="destructive" className="mt-3 w-full">
                  <a href={`tel:${c.number}`} aria-label={`Call ${c.name} at ${c.display}`}>
                    <Phone className="mr-2 h-4 w-4" />
                    Call {c.display}
                  </a>
                </Button>
              </div>
            ))}
          </div>
        </section>

        <h2 className="mt-8 text-lg font-semibold">Nearest safe exit route</h2>
        <div className="mt-3 grid gap-6 lg:grid-cols-[1fr_320px]">

          <div className="rounded-2xl border border-border/60 bg-card p-3">
            <div className="mb-3 flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm font-medium">
                <Building className="h-4 w-4 text-primary" />
                {floors.find((f) => f.id === floor)?.name}
              </div>
              <div className="flex gap-1">
                {floors.map((f) => (
                  <button
                    key={f.id}
                    onClick={() => setFloor(f.id)}
                    className={`rounded-md px-2.5 py-1 text-xs transition ${
                      f.id === floor
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {f.name}
                  </button>
                ))}
              </div>
            </div>
            <CampusMap
              nodes={nodes}
              edges={edges}
              floor={floor}
              planImage={floors.find((f) => f.id === floor)?.planImage}
              pathNodeIds={result?.path.nodes ?? []}
              startId={from}
              endId={result?.exitId}
              className="h-[420px] w-full sm:h-[520px]"
            />
          </div>

          <aside className="space-y-3">
            <div className="rounded-2xl border border-border/60 bg-card">
              <div className="border-b border-border/60 px-4 py-3 text-sm font-semibold">
                <DoorOpen className="mr-2 inline h-4 w-4 text-primary" />
                Directions
              </div>
              {result ? (
                <ol className="max-h-[420px] overflow-auto p-2">
                  {result.path.steps.map((s, i) => (
                    <li key={i} className="flex gap-3 rounded-lg p-2 text-sm">
                      <span className="mt-0.5 flex h-6 w-6 items-center justify-center rounded-full bg-destructive/10 text-xs font-semibold text-destructive">
                        {i + 1}
                      </span>
                      <div>
                        <div className="font-medium">{s.instruction}</div>
                        <div className="text-xs text-muted-foreground">Floor {s.to.floor} · {s.kind}</div>
                      </div>
                    </li>
                  ))}
                </ol>
              ) : (
                <div className="p-6 text-center text-sm text-muted-foreground">
                  No emergency exit reachable.
                </div>
              )}
            </div>
            <Button asChild variant="outline" className="w-full">
              <Link to="/destinations" search={{ from }}>Back to destinations</Link>
            </Button>
          </aside>
        </div>
      </main>
    </div>
  );
}
