import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import QRCode from "qrcode";
import { ScanLine } from "lucide-react";
import { SiteHeader } from "@/components/campus/SiteHeader";
import { Button } from "@/components/ui/button";
import { useCampus } from "@/lib/campus/store";

export const Route = createFileRoute("/qr-demo")({
  head: () => ({
    meta: [
      { title: "Demo QR Codes — Smart Path Navigation" },
      {
        name: "description",
        content: "Generate and display printable campus QR codes, including the Main Gate starting point.",
      },
      { property: "og:title", content: "Demo QR Codes — Smart Path Navigation" },
      { property: "og:description", content: "Display campus QR codes to test scanning from another phone." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: QrDemoPage,
});

function QrCard({ id, label }: { id: string; label: string }) {
  const [src, setSrc] = useState<string | null>(null);
  useEffect(() => {
    QRCode.toDataURL(`SMARTPATH:${id}`, { margin: 1, width: 420 })
      .then(setSrc)
      .catch(() => {});
  }, [id]);
  return (
    <div className="rounded-2xl border border-border/60 bg-card p-4 text-center">
      <div className="flex items-center justify-center rounded-xl bg-white p-4">
        {src ? (
          <img src={src} alt={`QR code for ${label}`} className="h-48 w-48" />
        ) : (
          <div className="h-48 w-48 animate-pulse rounded bg-muted" />
        )}
      </div>
      <div className="mt-3 font-semibold">{label}</div>
      <code className="text-xs text-muted-foreground">SMARTPATH:{id}</code>
    </div>
  );
}

function QrDemoPage() {
  const { nodes } = useCampus();
  const others = nodes.filter((n) => n.id !== "gate" && (n.isDestination || n.isEmergencyExit));

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main className="mx-auto max-w-4xl px-4 py-8">
        <h1 className="text-3xl font-bold tracking-tight">Demo QR Codes</h1>
        <p className="mt-2 text-muted-foreground">
          Display these on one screen and scan them with another phone to test the navigation flow.
        </p>

        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          <QrCard id="gate" label="Main Gate (start here)" />
          <div className="flex flex-col justify-center rounded-2xl border border-border/60 bg-card p-6">
            <h2 className="text-lg font-semibold">Test the flow</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Open the scanner on a second device, allow camera access, and point it at the Main Gate
              code.
            </p>
            <Button asChild className="mt-4">
              <Link to="/scan">
                <ScanLine className="mr-2 h-4 w-4" /> Open QR Scanner
              </Link>
            </Button>
          </div>
        </div>

        <h2 className="mt-10 text-xl font-semibold">Other campus locations</h2>
        <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {others.map((n) => (
            <QrCard key={n.id} id={n.id} label={n.label} />
          ))}
        </div>
      </main>
    </div>
  );
}
