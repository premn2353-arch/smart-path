import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { ArrowLeftRight, Clock, Layers, Navigation2, Ruler } from "lucide-react";
import { SiteHeader } from "@/components/campus/SiteHeader";
import { IndoorMapView } from "@/components/campus/IndoorMapView";
import { Button } from "@/components/ui/button";
import { useCampus, useCurrentLocation } from "@/lib/campus/store";
import type { FloorId } from "@/lib/campus/model";
import type { RouteMode } from "@/lib/campus/graph";
import { resolveRoute } from "@/lib/campus/navigation";

export const Route = createFileRoute("/shortest-path")({
  head: () => ({
    meta: [
      { title: "Shortest Path Finder — Smart Path Campus" },
      {
        name: "description",
        content:
          "Pick a starting point and a destination to see the shortest campus route with distance and walking time.",
      },
      { property: "og:title", content: "Shortest Path Finder — Smart Path Campus" },
      {
        property: "og:description",
        content: "Compare start and destination and get the shortest indoor route instantly.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ShortestPathPage,
});

const MODES: { id: RouteMode; label: string }[] = [
  { id: "shortest", label: "Shortest" },
  { id: "fastest", label: "Fastest" },
  { id: "accessible", label: "Wheelchair" },
  { id: "less-crowded", label: "Less crowded" },
];

const selectClass =
  "w-full rounded-lg border border-border/60 bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring";

function ShortestPathPage() {
  const { nodes, edges, floors } = useCampus();
  const current = useCurrentLocation();

  const options = useMemo(
    () => [...nodes].sort((a, b) => a.label.localeCompare(b.label)),
    [nodes],
  );

  const [from, setFrom] = useState(current?.id ?? options[0]?.id ?? "");
  const [to, setTo] = useState(
    options.find((n) => n.isDestination && n.id !== (current?.id ?? options[0]?.id))?.id ??
      options[1]?.id ??
      "",
  );
  const [mode, setMode] = useState<RouteMode>("shortest");

  const plan = useMemo(
    () => (from && to && from !== to ? resolveRoute(nodes, edges, from, to, mode) : null),
    [nodes, edges, from, to, mode],
  );

  const [floor, setFloor] = useState<FloorId | null>(null);
  const activeFloor = floor ?? plan?.start.floor ?? floors[0]?.id ?? 0;

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main className="mx-auto max-w-6xl px-4 py-6 sm:py-10">
        <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">Shortest path finder</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Choose where you are and where you want to go — we calculate the shortest walkable route.
        </p>

        <div className="mt-6 grid gap-3 rounded-2xl border border-border/60 bg-card p-4 sm:grid-cols-[1fr_auto_1fr]">
          <label className="block text-sm">
            <span className="mb-1 block text-muted-foreground">Starting location</span>
            <select className={selectClass} value={from} onChange={(e) => setFrom(e.target.value)}>
              {options.map((n) => (
                <option key={n.id} value={n.id}>
                  {n.label}
                </option>
              ))}
            </select>
          </label>
          <div className="flex items-end justify-center pb-1">
            <Button
              type="button"
              variant="outline"
              size="icon"
              aria-label="Swap start and destination"
              onClick={() => {
                setFrom(to);
                setTo(from);
              }}
            >
              <ArrowLeftRight className="h-4 w-4" />
            </Button>
          </div>
          <label className="block text-sm">
            <span className="mb-1 block text-muted-foreground">Destination</span>
            <select className={selectClass} value={to} onChange={(e) => setTo(e.target.value)}>
              {options.map((n) => (
                <option key={n.id} value={n.id}>
                  {n.label}
                </option>
              ))}
            </select>
          </label>

          <div className="flex flex-wrap gap-2 sm:col-span-3">
            {MODES.map((m) => (
              <button
                key={m.id}
                type="button"
                onClick={() => setMode(m.id)}
                className={`rounded-full px-3 py-1.5 text-xs font-medium transition ${
                  m.id === mode
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground hover:text-foreground"
                }`}
              >
                {m.label}
              </button>
            ))}
          </div>
        </div>

        {!plan ? (
          <div className="mt-6 rounded-2xl border border-border/60 bg-card p-8 text-center text-sm text-muted-foreground">
            {from === to
              ? "Pick two different locations to calculate a route."
              : "No route available between these locations."}
          </div>
        ) : (
          <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_340px]">
            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-3">
                <Stat icon={Ruler} label="Distance" value={`${Math.round(plan.path.distance)} m`} />
                <Stat icon={Clock} label="Walk time" value={`${plan.path.minutes} min`} />
                <Stat icon={Layers} label="Floors" value={String(plan.path.floors)} />
              </div>

              <div className="rounded-2xl border border-border/60 bg-card p-3">
                <div className="mb-3 flex flex-wrap gap-1">
                  {floors.map((f) => (
                    <button
                      key={f.id}
                      onClick={() => setFloor(f.id)}
                      className={`rounded-md px-2.5 py-1 text-xs transition ${
                        f.id === activeFloor
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      {f.name}
                    </button>
                  ))}
                </div>
                <IndoorMapView
                  nodes={nodes}
                  edges={edges}
                  floor={activeFloor}
                  planImage={floors.find((f) => f.id === activeFloor)?.planImage}
                  pathNodeIds={plan.path.nodes}
                  startId={plan.start.id}
                  endId={plan.end.id}
                  currentId={current?.id}
                />
              </div>
            </div>

            <aside className="space-y-3">
              <div className="rounded-2xl border border-border/60 bg-card">
                <div className="border-b border-border/60 px-4 py-3 text-sm font-semibold">
                  Directions
                </div>
                <ol className="max-h-[460px] overflow-auto p-2">
                  {plan.path.steps.map((s, i) => (
                    <li key={i} className="flex gap-3 rounded-lg p-2 text-sm">
                      <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-semibold text-primary">
                        {i + 1}
                      </span>
                      <div>
                        <div className="font-medium">{s.instruction}</div>
                        <div className="text-xs text-muted-foreground">
                          {Math.round(s.distance)} m · {s.kind}
                        </div>
                      </div>
                    </li>
                  ))}
                </ol>
              </div>
              <Button asChild className="w-full">
                <Link to="/navigate" search={{ from: plan.start.id, to: plan.end.id, mode }}>
                  <Navigation2 className="mr-2 h-4 w-4" />
                  Start turn-by-turn
                </Link>
              </Button>
            </aside>
          </div>
        )}
      </main>
    </div>
  );
}

function Stat({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-2xl border border-border/60 bg-card p-3">
      <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
        <Icon className="h-3.5 w-3.5" />
        {label}
      </div>
      <div className="mt-1 text-lg font-semibold">{value}</div>
    </div>
  );
}
