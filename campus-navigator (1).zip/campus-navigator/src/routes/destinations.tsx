import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Search, MapPin, Check, Navigation2 } from "lucide-react";
import { z } from "zod";
import { SiteHeader } from "@/components/campus/SiteHeader";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useCampus } from "@/lib/campus/store";
import { useOccupancy } from "@/lib/campus/occupancy-store";
import { CrowdBadge } from "@/components/campus/OccupancyBits";
import { cn } from "@/lib/utils";

const searchSchema = z.object({
  from: z.string().optional(),
});

export const Route = createFileRoute("/destinations")({
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: "Choose Destination — Smart Path Navigation" },
      { name: "description", content: "Search and select a destination on campus to get an indoor route." },
      { property: "og:title", content: "Choose Destination — Smart Path Navigation" },
      { property: "og:description", content: "Pick where you want to go and start navigation." },
    ],
  }),
  component: DestinationsPage,
});

function DestinationsPage() {
  const { from = "gate" } = Route.useSearch();
  const { nodes } = useCampus();
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const [selected, setSelected] = useState<string | null>(null);

  const start = nodes.find((n) => n.id === from);
  const destinations = useMemo(
    () =>
      nodes
        .filter((n) => n.isDestination)
        .filter((n) => n.label.toLowerCase().includes(q.trim().toLowerCase())),
    [nodes, q],
  );

  const { views } = useOccupancy();
  const occFor = (id?: string) => views.find((v) => v.nodeId === id && v.enabled) ?? null;

  const selectedNode = nodes.find((n) => n.id === selected);
  const selectedOcc = occFor(selectedNode?.id);
  const alternative =
    selectedOcc && selectedOcc.percent > 70
      ? views
          .filter((v) => v.kind === "place" && v.enabled && v.nodeId && v.nodeId !== selectedNode?.id)
          .sort((a, b) => a.percent - b.percent)[0] ?? null
      : null;

  return (
    <div className="min-h-screen bg-background pb-28">
      <SiteHeader />
      <main className="mx-auto max-w-3xl px-4 py-8">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <MapPin className="h-4 w-4 text-primary" />
          Starting from <span className="font-medium text-foreground">{start?.label ?? "Main Gate"}</span>
        </div>
        <h1 className="mt-2 text-2xl font-bold tracking-tight sm:text-3xl">
          Where would you like to go?
        </h1>

        <div className="mt-6 relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search destinations (Library, CSE Department, Canteen...)"
            className="h-12 pl-10"
          />
        </div>

        <ul className="mt-6 divide-y divide-border/60 overflow-hidden rounded-2xl border border-border/60 bg-card">
          {destinations.map((d) => {
            const isSel = selected === d.id;
            return (
              <li key={d.id}>
                <button
                  className={cn(
                    "flex w-full items-center justify-between gap-4 px-4 py-3 text-left transition hover:bg-muted",
                    isSel && "bg-primary/10",
                  )}
                  onClick={() => setSelected(d.id)}
                >
                  <div>
                    <div className="font-medium">{d.label}</div>
                    <div className="text-xs text-muted-foreground">
                      Floor {d.floor} · {d.type}
                    </div>
                    {occFor(d.id) && (
                      <div className="mt-1">
                        <CrowdBadge view={occFor(d.id)!} />
                      </div>
                    )}
                  </div>
                  {isSel ? (
                    <Check className="h-5 w-5 text-primary" />
                  ) : (
                    <span className="text-xs text-muted-foreground">Tap to select</span>
                  )}
                </button>
              </li>
            );
          })}
          {destinations.length === 0 && (
            <li className="px-4 py-8 text-center text-sm text-muted-foreground">
              No destinations match "{q}".
            </li>
          )}
        </ul>

        <div className="mt-6 text-sm text-muted-foreground">
          Need to change your starting point?{" "}
          <Link to="/scan" className="text-primary underline underline-offset-4">
            Scan again
          </Link>
          .
        </div>
      </main>

      {selectedNode && (
        <div className="fixed inset-x-0 bottom-0 z-20 border-t border-border/60 bg-background/95 p-4 backdrop-blur">
          <div className="mx-auto flex max-w-3xl items-center justify-between gap-3">
            <div className="min-w-0">
              <div className="truncate text-sm text-muted-foreground">Destination</div>
              <div className="truncate font-semibold">{selectedNode.label}</div>
              {selectedOcc && (
                <div className="mt-1 flex flex-wrap items-center gap-2">
                  <CrowdBadge view={selectedOcc} />
                  {alternative && (
                    <button
                      className="text-xs text-primary underline underline-offset-4"
                      onClick={() => setSelected(alternative.nodeId!)}
                    >
                      Find an alternative — {alternative.name} ({alternative.percent}%)
                    </button>
                  )}
                </div>
              )}
            </div>
            <Button
              size="lg"
              onClick={() =>
                navigate({
                  to: "/navigate",
                  search: { from: start?.id ?? "gate", to: selectedNode.id, mode: "shortest" },
                })
              }
            >
              <Navigation2 className="mr-2 h-4 w-4" />
              Find Best Route
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
