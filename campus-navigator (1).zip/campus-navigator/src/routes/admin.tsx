import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Plus, RotateCcw, Trash2, Ban, CircleCheck } from "lucide-react";
import { SiteHeader } from "@/components/campus/SiteHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { campusStore, useCampus } from "@/lib/campus/store";
import { type CampusNode, type FloorId, type NodeType } from "@/lib/campus/data";
import { FloorPlanManager } from "@/components/campus/admin/FloorPlanManager";
import { MapEditor, LOCATION_TYPES } from "@/components/campus/admin/MapEditor";
import { QrManager } from "@/components/campus/admin/QrManager";
import { occupancyStore, useOccupancy } from "@/lib/campus/occupancy-store";
import { OccupancyBar, statusClasses } from "@/components/campus/OccupancyBits";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Admin Dashboard — Smart Path Navigation" },
      { name: "description", content: "Manage campus buildings, rooms, floors, stairs, lifts, destinations and route availability." },
      { property: "og:title", content: "Admin Dashboard — Smart Path Navigation" },
      { property: "og:description", content: "Edit sample campus data used for indoor navigation." },
    ],
  }),
  component: AdminPage,
});

const TYPES: NodeType[] = LOCATION_TYPES.map((t) => t.value);

function AdminPage() {
  const { nodes, edges, floors } = useCampus();

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main className="mx-auto max-w-6xl px-4 py-8">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">Admin Dashboard</h1>
            <p className="text-sm text-muted-foreground">
              Add or edit locations, mark routes unavailable, and manage floors.
            </p>
          </div>
          <Button
            variant="outline"
            onClick={() => {
              if (confirm("Reset campus data to defaults?")) campusStore.reset();
            }}
          >
            <RotateCcw className="mr-2 h-4 w-4" />
            Reset data
          </Button>
        </div>

        <Tabs defaultValue="locations" className="mt-6">
          <TabsList className="flex flex-wrap">
            <TabsTrigger value="locations">Locations</TabsTrigger>
            <TabsTrigger value="add">Add location</TabsTrigger>
            <TabsTrigger value="plans">Campus map</TabsTrigger>
            <TabsTrigger value="editor">Map editor</TabsTrigger>
            <TabsTrigger value="qr">QR codes</TabsTrigger>
            <TabsTrigger value="routes">Routes</TabsTrigger>
            <TabsTrigger value="occupancy">Occupancy</TabsTrigger>
          </TabsList>

          <TabsContent value="locations" className="mt-4">
            <LocationsTable nodes={nodes} floors={floors} />
          </TabsContent>
          <TabsContent value="add" className="mt-4">
            <AddLocationForm />
          </TabsContent>
          <TabsContent value="plans" className="mt-4">
            <FloorPlanManager />
          </TabsContent>
          <TabsContent value="editor" className="mt-4">
            <MapEditor />
          </TabsContent>
          <TabsContent value="qr" className="mt-4">
            <QrManager />
          </TabsContent>
          <TabsContent value="routes" className="mt-4">
            <RoutesTable edges={edges} nodes={nodes} />
          </TabsContent>
          <TabsContent value="occupancy" className="mt-4">
            <OccupancyManager />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}

function LocationsTable({
  nodes,
  floors,
}: {
  nodes: CampusNode[];
  floors: ReturnType<typeof useCampus>["floors"];
}) {
  return (
    <div className="overflow-hidden rounded-2xl border border-border/60 bg-card">
      <div className="max-h-[560px] overflow-auto">
        <table className="w-full text-sm">
          <thead className="sticky top-0 bg-card text-xs uppercase text-muted-foreground">
            <tr>
              <th className="px-3 py-2 text-left">Label</th>
              <th className="px-3 py-2 text-left">Type</th>
              <th className="px-3 py-2 text-left">Floor</th>
              <th className="px-3 py-2 text-left">Destination</th>
              <th className="px-3 py-2 text-left">Accessible</th>
              <th className="px-3 py-2" />
            </tr>
          </thead>
          <tbody>
            {nodes.map((n) => (
              <tr key={n.id} className="border-t border-border/60">
                <td className="px-3 py-2">
                  <Input
                    defaultValue={n.label}
                    onBlur={(e) => campusStore.updateNode(n.id, { label: e.target.value })}
                    className="h-8"
                  />
                </td>
                <td className="px-3 py-2">
                  <Select
                    value={n.type}
                    onValueChange={(v) => campusStore.updateNode(n.id, { type: v as NodeType })}
                  >
                    <SelectTrigger className="h-8 w-32"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {TYPES.map((t) => (
                        <SelectItem key={t} value={t}>{t}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </td>
                <td className="px-3 py-2">
                  <Select
                    value={String(n.floor)}
                    onValueChange={(v) => campusStore.updateNode(n.id, { floor: Number(v) as FloorId })}
                  >
                    <SelectTrigger className="h-8 w-28"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {floors.map((f) => (
                        <SelectItem key={f.id} value={String(f.id)}>{f.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </td>
                <td className="px-3 py-2">
                  <Switch
                    checked={!!n.isDestination}
                    onCheckedChange={(v) => campusStore.updateNode(n.id, { isDestination: v })}
                  />
                </td>
                <td className="px-3 py-2">
                  <Switch
                    checked={!!n.accessible}
                    onCheckedChange={(v) => campusStore.updateNode(n.id, { accessible: v })}
                  />
                </td>
                <td className="px-3 py-2 text-right">
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => {
                      if (confirm(`Delete ${n.label}?`)) campusStore.removeNode(n.id);
                    }}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function AddLocationForm() {
  const { floors } = useCampus();
  const [form, setForm] = useState({
    id: "",
    label: "",
    type: "room" as NodeType,
    floor: 0 as FloorId,
    x: 50,
    y: 50,
    isDestination: true,
    accessible: true,
  });

  return (
    <form
      className="grid gap-4 rounded-2xl border border-border/60 bg-card p-5 sm:grid-cols-2"
      onSubmit={(e) => {
        e.preventDefault();
        if (!form.id || !form.label) return;
        campusStore.addNode({ ...form });
        setForm((f) => ({ ...f, id: "", label: "" }));
      }}
    >
      <Field label="ID (unique)">
        <Input value={form.id} onChange={(e) => setForm({ ...form, id: e.target.value })} placeholder="e.g. class401" required />
      </Field>
      <Field label="Label">
        <Input value={form.label} onChange={(e) => setForm({ ...form, label: e.target.value })} placeholder="Classroom 401" required />
      </Field>
      <Field label="Type">
        <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v as NodeType })}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            {TYPES.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
          </SelectContent>
        </Select>
      </Field>
      <Field label="Floor">
        <Select value={String(form.floor)} onValueChange={(v) => setForm({ ...form, floor: Number(v) as FloorId })}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            {floors.map((f) => <SelectItem key={f.id} value={String(f.id)}>{f.name}</SelectItem>)}
          </SelectContent>
        </Select>
      </Field>
      <Field label="X (0–100)">
        <Input type="number" min={0} max={100} value={form.x} onChange={(e) => setForm({ ...form, x: Number(e.target.value) })} />
      </Field>
      <Field label="Y (0–100)">
        <Input type="number" min={0} max={100} value={form.y} onChange={(e) => setForm({ ...form, y: Number(e.target.value) })} />
      </Field>
      <div className="flex items-center gap-6 sm:col-span-2">
        <label className="flex items-center gap-2 text-sm">
          <Switch checked={form.isDestination} onCheckedChange={(v) => setForm({ ...form, isDestination: v })} />
          Show as destination
        </label>
        <label className="flex items-center gap-2 text-sm">
          <Switch checked={form.accessible} onCheckedChange={(v) => setForm({ ...form, accessible: v })} />
          Wheelchair accessible
        </label>
      </div>
      <div className="sm:col-span-2">
        <Button type="submit"><Plus className="mr-2 h-4 w-4" /> Add location</Button>
        <p className="mt-2 text-xs text-muted-foreground">
          New locations have no connections yet — use the Map editor tab to draw walkable paths so A* can route to them.
        </p>
      </div>
    </form>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <Label className="mb-1.5 block text-xs font-medium text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}

function RoutesTable({
  edges,
  nodes,
}: {
  edges: ReturnType<typeof useCampus>["edges"];
  nodes: CampusNode[];
}) {
  const nodeMap = new Map(nodes.map((n) => [n.id, n]));
  return (
    <div className="overflow-hidden rounded-2xl border border-border/60 bg-card">
      <div className="max-h-[560px] overflow-auto">
        <table className="w-full text-sm">
          <thead className="sticky top-0 bg-card text-xs uppercase text-muted-foreground">
            <tr>
              <th className="px-3 py-2 text-left">From</th>
              <th className="px-3 py-2 text-left">To</th>
              <th className="px-3 py-2 text-left">Kind</th>
              <th className="px-3 py-2 text-left">Distance</th>
              <th className="px-3 py-2 text-left">Status</th>
              <th className="px-3 py-2" />
            </tr>
          </thead>
          <tbody>
            {edges.map((e, i) => (
              <tr key={i} className="border-t border-border/60">
                <td className="px-3 py-2">{nodeMap.get(e.from)?.label ?? e.from}</td>
                <td className="px-3 py-2">{nodeMap.get(e.to)?.label ?? e.to}</td>
                <td className="px-3 py-2 capitalize">{e.kind}</td>
                <td className="px-3 py-2">{e.weight} m</td>
                <td className="px-3 py-2">
                  {e.blocked ? (
                    <span className="inline-flex items-center gap-1 text-destructive">
                      <Ban className="h-3.5 w-3.5" /> Unavailable
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-emerald-600">
                      <CircleCheck className="h-3.5 w-3.5" /> Available
                    </span>
                  )}
                </td>
                <td className="px-3 py-2 text-right">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => campusStore.toggleEdgeBlocked(e.from, e.to)}
                  >
                    {e.blocked ? "Mark available" : "Mark unavailable"}
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function OccupancyManager() {
  const { views } = useOccupancy();
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-muted-foreground">
          Set capacity, adjust or reset live counts, and toggle tracking per location.
        </p>
        <Button
          variant="outline"
          onClick={() => {
            if (confirm("Reset all occupancy counters?")) occupancyStore.resetAll();
          }}
        >
          <RotateCcw className="mr-2 h-4 w-4" />
          Reset all occupancy
        </Button>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        {views.map((v) => (
          <div key={v.id} className="rounded-2xl border border-border/60 bg-card p-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="font-semibold">{v.name}</div>
                <div className={`text-xs font-medium ${statusClasses[v.status].text}`}>
                  {v.current}/{v.capacity} · {v.percent}% · {v.label}
                </div>
              </div>
              <label className="flex items-center gap-2 text-xs text-muted-foreground">
                Tracking
                <Switch
                  checked={v.enabled}
                  onCheckedChange={(on) => occupancyStore.setEnabled(v.id, on)}
                />
              </label>
            </div>
            <div className="mt-3">
              <OccupancyBar view={v} />
            </div>
            <div className="mt-3 grid grid-cols-2 gap-3">
              <Field label="Max capacity">
                <Input
                  type="number"
                  min={1}
                  className="h-8"
                  defaultValue={v.capacity}
                  onBlur={(e) => occupancyStore.setCapacity(v.id, Number(e.target.value))}
                />
              </Field>
              <Field label="Current count">
                <Input
                  type="number"
                  min={0}
                  className="h-8"
                  value={v.current}
                  onChange={(e) => occupancyStore.setCurrent(v.id, Number(e.target.value))}
                />
              </Field>
            </div>
            <div className="mt-3 flex gap-2">
              <Button size="sm" variant="outline" onClick={() => occupancyStore.adjust(v.id, -1)}>
                −1
              </Button>
              <Button size="sm" variant="outline" onClick={() => occupancyStore.adjust(v.id, 1)}>
                +1
              </Button>
              <Button
                size="sm"
                variant="ghost"
                className="ml-auto"
                onClick={() => occupancyStore.resetLocation(v.id)}
              >
                Reset
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
