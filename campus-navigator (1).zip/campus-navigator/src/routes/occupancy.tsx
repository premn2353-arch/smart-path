import { createFileRoute, Link } from "@tanstack/react-router";
import { Activity, LogIn, LogOut, MapPin, RotateCcw, Users } from "lucide-react";
import { SiteHeader } from "@/components/campus/SiteHeader";
import { Button } from "@/components/ui/button";
import { CrowdBadge, OccupancyCard } from "@/components/campus/OccupancyBits";
import { occupancyStore, useOccupancy } from "@/lib/campus/occupancy-store";
import { useCurrentLocation } from "@/lib/campus/store";
import { trackedIdsForNode } from "@/lib/campus/occupancy-store";

export const Route = createFileRoute("/occupancy")({
  head: () => ({
    meta: [
      { title: "Live Occupancy — Smart Path Navigation" },
      {
        name: "description",
        content:
          "See live crowd levels for the library, canteen, labs, seminar hall and each campus floor before you go.",
      },
      { property: "og:title", content: "Live Campus Occupancy — Smart Path Navigation" },
      {
        property: "og:description",
        content: "Anonymous, real-time crowd levels across campus locations and floors.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: OccupancyPage,
});

function OccupancyPage() {
  const { views, checkIns } = useOccupancy();
  const current = useCurrentLocation();

  const places = views.filter((v) => v.kind === "place");
  const floors = views.filter((v) => v.kind === "floor");

  const currentIds = current ? trackedIdsForNode(current.id, current.floor) : [];
  const canCheckIn = currentIds.length > 0;
  const checkedInHere =
    canCheckIn && currentIds.every((id) => checkIns.some((c) => c.locationId === id));

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main className="mx-auto max-w-5xl px-4 py-8">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h1 className="flex items-center gap-2 text-2xl font-bold tracking-tight sm:text-3xl">
              <Activity className="h-6 w-6 text-primary" />
              Live Occupancy
            </h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Anonymous crowd levels across campus. No personal information is shown or stored.
            </p>
          </div>
          {checkIns.length > 0 && (
            <Button variant="outline" onClick={() => occupancyStore.checkOutAll()}>
              <LogOut className="mr-2 h-4 w-4" />
              Check out of everywhere
            </Button>
          )}
        </div>

        {/* Check-in panel driven by the QR checkpoint */}
        <div className="mt-6 rounded-2xl border border-border/60 bg-card p-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-start gap-2 text-sm">
              <MapPin className="mt-0.5 h-4 w-4 text-primary" />
              <div>
                <div className="text-xs text-muted-foreground">Your scanned location</div>
                <div className="font-medium">{current ? current.label : "Not scanned yet"}</div>
              </div>
            </div>
            {current ? (
              canCheckIn ? (
                checkedInHere ? (
                  <Button variant="secondary" onClick={() => occupancyStore.checkOut(currentIds)}>
                    <LogOut className="mr-2 h-4 w-4" />
                    Check out of {current.label}
                  </Button>
                ) : (
                  <Button onClick={() => occupancyStore.checkIn(currentIds)}>
                    <LogIn className="mr-2 h-4 w-4" />
                    Check in at {current.label}
                  </Button>
                )
              ) : (
                <span className="text-xs text-muted-foreground">
                  This location is not occupancy-tracked.
                </span>
              )
            ) : (
              <Button asChild variant="outline">
                <Link to="/scan">Scan a location QR</Link>
              </Button>
            )}
          </div>
        </div>

        <h2 className="mt-8 text-sm font-semibold uppercase tracking-wide text-muted-foreground">
          Locations
        </h2>
        <div className="mt-3 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {places.map((v) => {
            const ids = v.nodeId ? [v.id] : [v.id];
            const isIn = checkIns.some((c) => c.locationId === v.id);
            return (
              <OccupancyCard
                key={v.id}
                view={v}
                action={
                  v.enabled ? (
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant={isIn ? "secondary" : "outline"}
                        className="flex-1"
                        onClick={() =>
                          isIn ? occupancyStore.checkOut(ids) : occupancyStore.checkIn(ids)
                        }
                      >
                        {isIn ? (
                          <>
                            <LogOut className="mr-1.5 h-3.5 w-3.5" /> Check out
                          </>
                        ) : (
                          <>
                            <LogIn className="mr-1.5 h-3.5 w-3.5" /> Check in
                          </>
                        )}
                      </Button>
                      {v.nodeId && (
                        <Button asChild size="sm" variant="ghost">
                          <Link
                            to="/navigate"
                            search={{ from: "gate", to: v.nodeId, mode: "shortest" }}
                          >
                            Route
                          </Link>
                        </Button>
                      )}
                    </div>
                  ) : null
                }
              />
            );
          })}
        </div>

        <h2 className="mt-8 text-sm font-semibold uppercase tracking-wide text-muted-foreground">
          Floors
        </h2>
        <div className="mt-3 grid gap-4 sm:grid-cols-3">
          {floors.map((v) => (
            <OccupancyCard key={v.id} view={v} />
          ))}
        </div>

        <div className="mt-8 flex flex-wrap items-center gap-3 rounded-2xl bg-muted/60 p-4 text-xs text-muted-foreground">
          <Users className="h-4 w-4 text-primary" />
          Crowd bands: 0–40% Low · 41–70% Medium · 71–100% High · above 100% Over Capacity.
          <span className="inline-flex items-center gap-2">
            Least busy right now:
            {(() => {
              const best = [...places.filter((p) => p.enabled)].sort((a, b) => a.percent - b.percent)[0];
              return best ? <CrowdBadge view={best} /> : null;
            })()}
          </span>
          <Button
            size="sm"
            variant="ghost"
            className="ml-auto"
            onClick={() => {
              if (confirm("Reset all occupancy counters to sample values?")) occupancyStore.resetAll();
            }}
          >
            <RotateCcw className="mr-1.5 h-3.5 w-3.5" />
            Reset demo data
          </Button>
        </div>
      </main>
    </div>
  );
}
