import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { z } from "zod";
import {
  Accessibility,
  ArrowUpDown,
  Clock,
  Footprints,
  Layers,
  MapPin,
  Navigation2,
  RefreshCw,
  Ruler,
  Square,
  Play,
  Zap,
  ArrowUp,
  Building,
  MoveRight,
  ChevronLeft,
  ChevronRight,
  Users,
  Volume2,
  VolumeX,
} from "lucide-react";
import { SiteHeader } from "@/components/campus/SiteHeader";
import { IndoorMapView } from "@/components/campus/IndoorMapView";
import { Button } from "@/components/ui/button";
import { useCampus, useCurrentLocation } from "@/lib/campus/store";
import { type FloorId } from "@/lib/campus/data";
import type { RouteMode } from "@/lib/campus/graph";
import { floorForStep, resolveRoute } from "@/lib/campus/navigation";
import { useOccupancy } from "@/lib/campus/occupancy-store";
import { crowdPenalty } from "@/lib/campus/occupancy";
import { CrowdBadge, OccupancyBar } from "@/components/campus/OccupancyBits";
import { useVoiceGuidance } from "@/lib/campus/use-voice-guidance";

const modes: { id: RouteMode; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: "shortest", label: "Shortest", icon: Ruler },
  { id: "fastest", label: "Fastest", icon: Zap },
  { id: "lift", label: "Lift", icon: ArrowUpDown },
  { id: "stair", label: "Staircase", icon: ArrowUp },
  { id: "accessible", label: "Wheelchair", icon: Accessibility },
  { id: "less-crowded", label: "Less Crowded", icon: Users },
];

const searchSchema = z.object({
  from: z.string().default("gate"),
  to: z.string(),
  mode: z
    .enum(["shortest", "fastest", "lift", "stair", "accessible", "less-crowded", "emergency"])
    .default("shortest"),
});

export const Route = createFileRoute("/navigate")({
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: "Route — Smart Path Navigation" },
      { name: "description", content: "Follow the shortest indoor route across the campus." },
      { property: "og:title", content: "Route — Smart Path Navigation" },
      { property: "og:description", content: "Step-by-step campus navigation with distance and walking time." },
    ],
  }),
  component: NavigatePage,
});

function NavigatePage() {
  const { from, to, mode } = Route.useSearch();
  const navigate = Route.useNavigate();
  const { nodes, edges, floors } = useCampus();
  const checkedIn = useCurrentLocation();
  const { views } = useOccupancy();
  const [recalcTick, setRecalcTick] = useState(0);

  // The QR checkpoint wins when the URL still carries the default start.
  const startId = from === "gate" && checkedIn ? checkedIn.id : from;

  // Crowd-aware routing only kicks in when the user explicitly picks it.
  const nodeCost = useMemo(() => {
    const m = new Map<string, number>();
    if (mode !== "less-crowded") return m;
    for (const v of views) {
      if (v.enabled && v.nodeId) m.set(v.nodeId, crowdPenalty(v.percent));
    }
    return m;
  }, [views, mode]);

  const plan = useMemo(
    () => resolveRoute(nodes, edges, startId, to, mode, { nodeCost }),
    // recalcTick forces a fresh compute when the user hits "Recalculate"
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [nodes, edges, startId, to, mode, recalcTick, nodeCost],
  );

  const [navigating, setNavigating] = useState(false);
  const [stepIndex, setStepIndex] = useState(0);
  const [manualFloor, setManualFloor] = useState<FloorId | null>(null);

  // Reset the session whenever the route itself changes.
  useEffect(() => {
    setStepIndex(0);
    setManualFloor(null);
  }, [startId, to, mode, recalcTick]);

  const autoFloor: FloorId = plan
    ? navigating
      ? floorForStep(plan, stepIndex)
      : plan.start.floor
    : 0;
  const activeFloor = manualFloor ?? autoFloor;

  const destOccupancy = views.find((v) => v.nodeId === to && v.enabled) ?? null;
  const routeOccupancy = (plan?.path.nodes ?? [])
    .map((id) => views.find((v) => v.nodeId === id && v.enabled))
    .filter((v): v is NonNullable<typeof v> => !!v);

  const steps = plan?.path.steps ?? [];
  const activeStep = navigating ? steps[stepIndex] : undefined;

  // ---- Voice guidance ----------------------------------------------------
  const voice = useVoiceGuidance();
  const spokenIntro = useRef(false);

  useEffect(() => {
    spokenIntro.current = false;
  }, [startId, to, mode, recalcTick]);

  useEffect(() => {
    if (!navigating || !plan || !voice.enabled) return;
    if (!spokenIntro.current) {
      spokenIntro.current = true;
      voice.speak(
        `Calculating route to ${plan.end.label}. Starting route. Proceed to the highlighted route.`,
        { force: true },
      );
      return;
    }
    const line = activeStep
      ? activeStep.instruction
      : `You have arrived at your destination: ${plan.end.label}.`;
    voice.speak(line);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [navigating, stepIndex, plan?.end.label, voice.enabled, activeStep?.instruction]);

  useEffect(() => {
    if (!navigating) voice.cancel();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [navigating]);

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main className="mx-auto max-w-6xl px-4 py-8">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <div className="text-sm text-muted-foreground">
              {plan?.start.label ?? startId} <MoveRight className="inline h-3 w-3" />{" "}
              {plan?.end.label ?? to}
            </div>
            <h1 className="mt-1 text-2xl font-bold tracking-tight sm:text-3xl">
              {plan?.end.label ?? "Destination"}
            </h1>
          </div>
          <Button asChild variant="outline">
            <Link to="/destinations" search={{ from: startId }}>
              Change destination
            </Link>
          </Button>
        </div>

        {/* Route preferences */}
        <div className="mt-6 flex flex-wrap gap-2">
          {modes.map((m) => {
            const active = m.id === mode;
            return (
              <button
                key={m.id}
                onClick={() => navigate({ search: { from: startId, to, mode: m.id } })}
                className={`inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-sm transition ${
                  active
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-border bg-card text-foreground hover:bg-muted"
                }`}
              >
                <m.icon className="h-4 w-4" /> {m.label}
              </button>
            );
          })}
        </div>

        {plan?.fallbackFrom && (
          <p className="mt-3 rounded-xl border border-amber-500/40 bg-amber-500/10 px-4 py-2 text-sm">
            The <strong>{plan.fallbackFrom}</strong> route is unavailable (a connection is blocked) —
            showing the closest alternative <strong>{plan.mode}</strong> route instead.
          </p>
        )}

        <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_360px]">
          {/* Map */}
          <div className="rounded-2xl border border-border/60 bg-card p-3">
            <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-sm font-medium">
                <Building className="h-4 w-4 text-primary" />
                {floors.find((f) => f.id === activeFloor)?.name}
                {navigating && manualFloor === null && (
                  <span className="rounded-full bg-primary/10 px-2 py-0.5 text-xs text-primary">
                    following route
                  </span>
                )}
              </div>
              <div className="flex gap-1">
                {floors.map((f) => (
                  <button
                    key={f.id}
                    onClick={() => setManualFloor(f.id === autoFloor ? null : f.id)}
                    className={`rounded-md px-2.5 py-1 text-xs transition ${
                      f.id === activeFloor
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {f.name}
                  </button>
                ))}
              </div>
            </div>
            <IndoorMapView
              nodes={nodes}
              edges={edges}
              floor={activeFloor}
              planImage={floors.find((f) => f.id === activeFloor)?.planImage}
              pathNodeIds={plan?.path.nodes ?? []}
              startId={startId}
              endId={to}
              currentId={activeStep?.from.id ?? (navigating ? startId : undefined)}
            />
          </div>

          {/* Sidebar */}
          <aside className="space-y-4">
            {plan ? (
              <>
                <div className="grid grid-cols-3 gap-3">
                  <Stat icon={Ruler} label="Distance" value={`${plan.path.distance} m`} />
                  <Stat icon={Clock} label="Walk time" value={`~${plan.path.minutes} min`} />
                  <Stat icon={Layers} label="Floors" value={`${plan.path.floors}`} />
                </div>

                <div className="rounded-2xl border border-border/60 bg-card p-4 text-sm">
                  <div className="flex items-start gap-2">
                    <MapPin className="mt-0.5 h-4 w-4 text-primary" />
                    <div>
                      <div className="text-xs text-muted-foreground">Current location</div>
                      <div className="font-medium">{plan.start.label}</div>
                    </div>
                  </div>
                  <div className="mt-3 flex items-start gap-2">
                    <Navigation2 className="mt-0.5 h-4 w-4 text-destructive" />
                    <div>
                      <div className="text-xs text-muted-foreground">Destination</div>
                      <div className="font-medium">{plan.end.label}</div>
                      {destOccupancy && (
                        <div className="mt-1">
                          <CrowdBadge view={destOccupancy} />
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {routeOccupancy.length > 0 && (
                  <div className="rounded-2xl border border-border/60 bg-card p-4">
                    <div className="flex items-center gap-2 text-sm font-semibold">
                      <Users className="h-4 w-4 text-primary" />
                      Crowd along this route
                    </div>
                    <ul className="mt-3 space-y-3">
                      {routeOccupancy.map((v) => (
                        <li key={v.id}>
                          <div className="flex items-center justify-between text-xs">
                            <span className="font-medium">{v.name}</span>
                            <span className="text-muted-foreground">
                              {v.current}/{v.capacity} · {v.label}
                            </span>
                          </div>
                          <div className="mt-1">
                            <OccupancyBar view={v} />
                          </div>
                        </li>
                      ))}
                    </ul>
                    {mode !== "less-crowded" && (
                      <Button
                        size="sm"
                        variant="outline"
                        className="mt-3 w-full"
                        onClick={() =>
                          navigate({ search: { from: startId, to, mode: "less-crowded" } })
                        }
                      >
                        Use a less crowded route
                      </Button>
                    )}
                  </div>
                )}

                {!navigating ? (
                  <Button className="w-full" onClick={() => setNavigating(true)}>
                    <Play className="mr-2 h-4 w-4" />
                    Start Navigation
                  </Button>
                ) : (
                  <div className="space-y-3 rounded-2xl border border-primary/40 bg-primary/5 p-4">
                    <div className="text-xs font-medium uppercase tracking-wide text-primary">
                      Step {Math.min(stepIndex + 1, steps.length)} of {steps.length}
                    </div>
                    <div className="text-sm font-medium">
                      {activeStep ? activeStep.instruction : `Arrive at ${plan.end.label}`}
                    </div>
                    {voice.supported && (
                      <div className="flex items-center gap-2">
                        <Button
                          size="sm"
                          variant={voice.enabled ? "secondary" : "outline"}
                          onClick={voice.toggle}
                          aria-pressed={voice.enabled}
                        >
                          {voice.enabled ? (
                            <Volume2 className="mr-2 h-4 w-4" />
                          ) : (
                            <VolumeX className="mr-2 h-4 w-4" />
                          )}
                          Voice {voice.enabled ? "on" : "off"}
                        </Button>
                        {voice.enabled && (
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() =>
                              voice.speak(
                                activeStep
                                  ? activeStep.instruction
                                  : `You have arrived at your destination: ${plan.end.label}.`,
                                { force: true },
                              )
                            }
                          >
                            Repeat
                          </Button>
                        )}
                        {voice.speaking && (
                          <span className="text-xs text-muted-foreground">Speaking…</span>
                        )}
                      </div>
                    )}
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="secondary"
                        disabled={stepIndex === 0}
                        onClick={() => setStepIndex((i) => Math.max(0, i - 1))}
                      >
                        <ChevronLeft className="h-4 w-4" /> Back
                      </Button>
                      <Button
                        size="sm"
                        className="flex-1"
                        disabled={stepIndex >= steps.length - 1}
                        onClick={() => {
                          setManualFloor(null);
                          setStepIndex((i) => Math.min(steps.length - 1, i + 1));
                        }}
                      >
                        Next <ChevronRight className="h-4 w-4" />
                      </Button>
                    </div>
                    <Button
                      size="sm"
                      variant="destructive"
                      className="w-full"
                      onClick={() => {
                        setNavigating(false);
                        setStepIndex(0);
                        setManualFloor(null);
                      }}
                    >
                      <Square className="mr-2 h-4 w-4" />
                      Stop Navigation
                    </Button>
                  </div>
                )}

                <Button
                  variant="secondary"
                  className="w-full"
                  onClick={() => setRecalcTick((t) => t + 1)}
                >
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Recalculate Route
                </Button>

                {/* Floor-by-floor plan */}
                <div className="rounded-2xl border border-border/60 bg-card">
                  <div className="border-b border-border/60 px-4 py-3 text-sm font-semibold">
                    Floor-by-floor directions
                  </div>
                  <div className="max-h-[460px] overflow-auto p-2">
                    {plan.segments.map((seg, si) => {
                      const offset = plan.segments
                        .slice(0, si)
                        .reduce((a, s) => a + s.steps.length, 0);
                      return (
                        <div key={si} className="mb-2">
                          <button
                            onClick={() => setManualFloor(seg.floor)}
                            className="mb-1 w-full rounded-lg bg-muted px-3 py-1.5 text-left text-xs font-semibold"
                          >
                            {floors.find((f) => f.id === seg.floor)?.name}
                            {seg.transition && (
                              <span className="ml-2 font-normal text-muted-foreground">
                                · {seg.transition.label} to floor {seg.transition.to}
                              </span>
                            )}
                          </button>
                          <ol>
                            {seg.steps.map((s, i) => {
                              const idx = offset + i;
                              const isActive = navigating && idx === stepIndex;
                              return (
                                <li
                                  key={i}
                                  className={`flex gap-3 rounded-lg p-2 text-sm ${
                                    isActive ? "bg-primary/10" : "hover:bg-muted"
                                  }`}
                                >
                                  <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-semibold text-primary">
                                    {idx + 1}
                                  </span>
                                  <div>
                                    <div className="font-medium">{s.instruction}</div>
                                    <div className="text-xs text-muted-foreground">
                                      Floor {s.to.floor} · {s.kind} · {Math.round(s.distance)} m
                                    </div>
                                  </div>
                                </li>
                              );
                            })}
                          </ol>
                        </div>
                      );
                    })}
                    <div className="flex gap-3 rounded-lg p-2 text-sm">
                      <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-semibold text-primary-foreground">
                        ✓
                      </span>
                      <div className="font-medium">Arrive at {plan.end.label}</div>
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <div className="space-y-3 rounded-2xl border border-dashed border-border p-6 text-center text-sm text-muted-foreground">
                <Navigation2 className="mx-auto h-6 w-6" />
                <p>
                  No route available for the <strong>{mode}</strong> preference — every path may be
                  blocked right now.
                </p>
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => setRecalcTick((t) => t + 1)}
                >
                  Try again
                </Button>
              </div>
            )}
            <Button asChild variant="outline" className="w-full">
              <Link to="/emergency" search={{ from: startId }}>
                <Footprints className="mr-2 h-4 w-4" />
                Nearest emergency exit
              </Link>
            </Button>
          </aside>
        </div>
      </main>
    </div>
  );
}

function Stat({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-2xl border border-border/60 bg-card p-4">
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <Icon className="h-3.5 w-3.5" />
        {label}
      </div>
      <div className="mt-1 text-xl font-semibold">{value}</div>
    </div>
  );
}
