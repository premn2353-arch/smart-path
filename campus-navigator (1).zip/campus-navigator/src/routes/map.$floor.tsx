import { createFileRoute, Link, notFound, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { MapPin, Navigation2, QrCode } from "lucide-react";
import { SiteHeader } from "@/components/campus/SiteHeader";
import { IndoorMapView } from "@/components/campus/IndoorMapView";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useCampus, useCurrentLocation } from "@/lib/campus/store";
import { CAMPUS, floorBySlug } from "@/lib/campus/data";
import type { CampusNode } from "@/lib/campus/model";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/map/$floor")({
  loader: ({ params }) => {
    // Floors can be added by an admin at runtime, so only the sample floors are
    // resolvable here; unknown slugs are matched against the live store instead.
    return { slug: params.floor, name: floorBySlug(params.floor)?.name ?? "Campus Floor" };
  },
  head: ({ loaderData }) => {
    const name = loaderData?.name ?? "Campus Floor";
    return {
      meta: [
        { title: `${name} Map — Smart Path Navigation` },
        {
          name: "description",
          content: `Interactive indoor map of the ${name}: rooms, labs, departments, corridors, staircases, lifts and emergency exits.`,
        },
        { property: "og:title", content: `${name} Map — Smart Path Navigation` },
        { property: "og:description", content: `Explore the ${name} indoor map and find any campus location.` },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary" },
      ],
    };
  },
  component: FloorMapPage,
});

function FloorMapPage() {
  const { slug } = Route.useLoaderData();
  const { nodes, edges, floors, buildings } = useCampus();
  const floor = floors.find((f) => f.slug === slug) ?? floors[0];
  const current = useCurrentLocation();
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const [selected, setSelected] = useState<CampusNode | null>(null);

  if (!floor) throw notFound();

  const onFloor = useMemo(
    () =>
      nodes
        .filter((n) => n.floor === floor.id && n.type !== "corridor")
        .filter((n) => {
          const t = q.trim().toLowerCase();
          if (!t) return true;
          return (
            n.label.toLowerCase().includes(t) ||
            n.code?.toLowerCase().includes(t) ||
            n.aliases?.some((a) => a.toLowerCase().includes(t))
          );
        }),
    [nodes, floor.id, q],
  );

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main className="mx-auto max-w-5xl px-4 py-8">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <MapPin className="h-4 w-4 text-primary" /> {CAMPUS.name} ·{" "}
          {buildings.find((b) => b.id === floor.buildingId)?.name ?? buildings[0]?.name}
        </div>
        <h1 className="mt-2 text-2xl font-bold tracking-tight sm:text-3xl">{floor.name} Map</h1>

        <div className="mt-4 flex flex-wrap gap-2">
          {floors.map((f) => (
            <Link
              key={f.id}
              to="/map/$floor"
              params={{ floor: f.slug }}
              className={cn(
                "rounded-full border border-border/60 px-4 py-1.5 text-sm transition hover:bg-muted",
                f.id === floor.id && "border-primary bg-primary text-primary-foreground hover:bg-primary",
              )}
            >
              {f.name}
            </Link>
          ))}
        </div>

        {current && (
          <div className="mt-4 flex items-center gap-2 rounded-xl border border-primary/40 bg-primary/10 px-3 py-2 text-sm text-primary">
            <QrCode className="h-4 w-4" />
            Current location: <span className="font-semibold">{current.label}</span>
            {current.floor !== floor.id && (
              <Link
                to="/map/$floor"
                params={{ floor: floors.find((f) => f.id === current.floor)?.slug ?? floor.slug }}
                className="underline underline-offset-4"
              >
                Show on its floor
              </Link>
            )}
          </div>
        )}

        <div className="mt-6 grid gap-6 lg:grid-cols-[1.4fr_1fr]">
          <IndoorMapView
            nodes={nodes}
            edges={edges}
            floor={floor.id}
            planImage={floor.planImage}
            currentId={current && current.floor === floor.id ? current.id : undefined}
            endId={selected && selected.floor === floor.id ? selected.id : undefined}
            onSelectNode={setSelected}
          />

          <div>
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search this floor (Lab, CSE, Library...)"
              className="h-11"
              aria-label="Search locations on this floor"
            />
            <ul className="mt-3 max-h-[28rem] divide-y divide-border/60 overflow-auto rounded-2xl border border-border/60 bg-card">
              {onFloor.map((n) => (
                <li key={n.id}>
                  <button
                    onClick={() => setSelected(n)}
                    className={cn(
                      "w-full px-4 py-2.5 text-left transition hover:bg-muted",
                      selected?.id === n.id && "bg-primary/10",
                    )}
                  >
                    <div className="text-sm font-medium">{n.label}</div>
                    <div className="text-xs capitalize text-muted-foreground">
                      {n.type}
                      {n.code ? ` · ${n.code}` : ""}
                    </div>
                  </button>
                </li>
              ))}
              {onFloor.length === 0 && (
                <li className="px-4 py-8 text-center text-sm text-muted-foreground">
                  No locations match "{q}".
                </li>
              )}
            </ul>

            {selected && (
              <div className="mt-4 rounded-2xl border border-border/60 bg-card p-4">
                <div className="font-semibold">{selected.label}</div>
                <div className="text-xs capitalize text-muted-foreground">
                  {selected.type} · {floors.find((f) => f.id === selected.floor)?.name}
                </div>
                <Button
                  className="mt-3 w-full"
                  onClick={() =>
                    navigate({
                      to: "/navigate",
                      search: { from: current?.id ?? "gate", to: selected.id, mode: "shortest" },
                    })
                  }
                >
                  <Navigation2 className="mr-2 h-4 w-4" /> Route here
                </Button>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
