import { createFileRoute, Link } from "@tanstack/react-router";
import {
  QrCode,
  Navigation2,
  MapPin,
  Shield,
  Accessibility,
  Building2,
  Users,
  Route as RouteIcon,
  Settings,
  ChevronRight,
} from "lucide-react";
import { SiteHeader } from "@/components/campus/SiteHeader";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Smart Path Navigation for Our Campus" },
      {
        name: "description",
        content:
          "Scan a QR code at the main gate, pick a destination, and get turn-by-turn indoor directions across our college campus.",
      },
      { property: "og:title", content: "Smart Path Navigation for Our Campus" },
      {
        property: "og:description",
        content:
          "Indoor campus wayfinding for students, staff and visitors. Shortest routes, floor changes, and emergency exits.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: HomePage,
});

function HomePage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />
      <main className="mx-auto max-w-6xl px-4 pb-20">
        {/* Hero */}
        <section className="relative overflow-hidden rounded-3xl border border-border/60 bg-gradient-to-br from-primary/10 via-background to-accent px-5 py-12 sm:px-12 sm:py-24 mt-6 sm:mt-8">
          <div className="max-w-2xl">
            <p className="mb-4 inline-flex items-center gap-2 rounded-full border border-border/60 bg-background/80 px-3 py-1 text-xs font-medium text-muted-foreground">
              <span className="h-1.5 w-1.5 rounded-full bg-primary" /> Indoor campus wayfinding
            </p>
            <h1 className="text-3xl font-bold tracking-tight sm:text-5xl">
              Smart Path Navigation for Our Campus
            </h1>
            <p className="mt-4 text-base text-muted-foreground sm:text-lg">
              Scan the QR code at the main gate, choose where you want to go, and follow the
              shortest route to any classroom, lab, or office — across every floor.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
              <Button asChild size="lg" className="w-full sm:w-auto">
                <Link to="/scan">
                  <QrCode className="mr-2 h-4 w-4" />
                  Scan QR Code
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="w-full sm:w-auto">
                <Link to="/destinations">
                  <Navigation2 className="mr-2 h-4 w-4" />
                  Start Navigation
                </Link>
              </Button>
            </div>
          </div>
        </section>

        {/* Quick actions — every card navigates */}
        <section className="mt-10">
          <h2 className="text-lg font-semibold">Quick actions</h2>
          <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            <ActionCard
              to="/emergency"
              search={{ from: "gate" }}
              icon={Shield}
              title="Emergency"
              body="Emergency contacts, call buttons and the nearest safe exit route."
              tone="danger"
            />
            <ActionCard
              to="/shortest-path"
              icon={RouteIcon}
              title="Shortest Path"
              body="Pick a start and destination to see distance and walking time."
            />
            <ActionCard
              to="/indoor"
              icon={Building2}
              title="Indoor Navigation"
              body="Choose building, floor and room for an indoor route."
            />
            <ActionCard
              to="/occupancy"
              icon={Users}
              title="Live Occupancy"
              body="See how crowded the library, canteen and labs are right now."
            />
            <ActionCard
              to="/map/$floor"
              params={{ floor: "ground" }}
              icon={MapPin}
              title="Campus Map"
              body="Explore the interactive indoor map floor by floor."
            />
            <ActionCard
              to="/admin"
              icon={Settings}
              title="Admin Dashboard"
              body="Manage buildings, floor plans, locations, QR codes and occupancy."
            />
          </div>
        </section>

        {/* Features */}
        <section className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {[
            { icon: MapPin, title: "Interactive indoor map", body: "Buildings, corridors, stairs and lifts across every floor." },
            { icon: Navigation2, title: "Shortest path", body: "A*-powered routing with distance and walking time." },
            { icon: Building2, title: "Multi-floor navigation", body: "Automatic staircase and lift transitions between floors." },
            { icon: Accessibility, title: "Accessible routes", body: "Wheelchair-friendly routing that avoids staircases." },
            { icon: Shield, title: "Emergency exits", body: "One-tap route to the nearest emergency exit." },
            { icon: QrCode, title: "QR-first onboarding", body: "Scan at the gate and start navigating instantly." },
          ].map((f) => (
            <div key={f.title} className="rounded-2xl border border-border/60 bg-card p-5">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <f.icon className="h-5 w-5" />
              </div>
              <h3 className="mt-4 font-semibold">{f.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{f.body}</p>
            </div>
          ))}
        </section>
      </main>
    </div>
  );
}

function ActionCard({
  icon: Icon,
  title,
  body,
  tone,
  ...link
}: {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  body: string;
  tone?: "danger";
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [key: string]: any;
}) {
  return (
    <Link
      {...(link as { to: string })}
      className="group flex items-start gap-3 rounded-2xl border border-border/60 bg-card p-5 transition hover:border-primary/50 hover:shadow-sm"
    >
      <span
        className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-lg ${
          tone === "danger" ? "bg-destructive/10 text-destructive" : "bg-primary/10 text-primary"
        }`}
      >
        <Icon className="h-5 w-5" />
      </span>
      <span className="min-w-0 flex-1">
        <span className="flex items-center gap-1 font-semibold">
          {title}
          <ChevronRight className="h-4 w-4 text-muted-foreground transition group-hover:translate-x-0.5" />
        </span>
        <span className="mt-1 block text-sm text-muted-foreground">{body}</span>
      </span>
    </Link>
  );
}

