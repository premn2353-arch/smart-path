// Navigation session logic — pure, UI-free.
// Builds a floor-by-floor route plan from an A* path (see `graph.ts`) and
// resolves automatic fallbacks when a preference has no available route.

import type { CampusEdge, CampusNode, FloorId } from "./model";
import { findPath, type PathOptions, type PathResult, type RouteMode, type RouteStep } from "./graph";

export interface FloorSegment {
  floor: FloorId;
  /** Node ids visited on this floor, in order. */
  nodeIds: string[];
  steps: RouteStep[];
  distance: number;
  /** How the user leaves this floor, if at all. */
  transition?: { kind: "stair" | "lift"; to: FloorId; label: string };
}

export interface RoutePlan {
  path: PathResult;
  start: CampusNode;
  end: CampusNode;
  /** The mode actually used (may differ from the requested one — see `fallback`). */
  mode: RouteMode;
  /** Set when the requested mode had no route and another one was used. */
  fallbackFrom?: RouteMode;
  segments: FloorSegment[];
  floors: FloorId[];
}

/** Preference order tried when the requested mode yields no route. */
const FALLBACK_ORDER: RouteMode[] = ["shortest", "fastest", "lift", "stair"];

/**
 * Calculate a route with automatic recovery: blocked connections are already
 * excluded by `findPath`, and if the chosen preference becomes impossible we
 * fall back to the next best mode (never stairs for accessible routes).
 */
export function resolveRoute(
  nodes: CampusNode[],
  edges: CampusEdge[],
  startId: string,
  endId: string,
  mode: RouteMode = "shortest",
  opts: PathOptions = {},
): RoutePlan | null {
  const nodeMap = new Map(nodes.map((n) => [n.id, n]));
  const start = nodeMap.get(startId);
  const end = nodeMap.get(endId);
  if (!start || !end) return null;

  let usedMode = mode;
  let path = findPath(nodes, edges, startId, endId, mode, opts);

  if (!path) {
    // Wheelchair routes must never silently fall back onto stairs.
    const candidates =
      mode === "accessible" ? ["lift" as RouteMode] : FALLBACK_ORDER.filter((m) => m !== mode);
    for (const m of candidates) {
      const p = findPath(nodes, edges, startId, endId, m, opts);
      if (p) {
        path = p;
        usedMode = m;
        break;
      }
    }
    if (!path) return null;
  }

  return {
    path,
    start,
    end,
    mode: usedMode,
    fallbackFrom: usedMode === mode ? undefined : mode,
    segments: buildFloorSegments(path, nodeMap),
    floors: floorsOf(path, nodeMap),
  };
}

function floorsOf(path: PathResult, nodeMap: Map<string, CampusNode>): FloorId[] {
  const seen: FloorId[] = [];
  for (const id of path.nodes) {
    const f = nodeMap.get(id)?.floor;
    if (f !== undefined && seen[seen.length - 1] !== f) seen.push(f);
  }
  return seen;
}

/** Split the path into consecutive per-floor legs with stair/lift transitions. */
export function buildFloorSegments(
  path: PathResult,
  nodeMap: Map<string, CampusNode>,
): FloorSegment[] {
  const segments: FloorSegment[] = [];
  if (path.nodes.length === 0) return segments;

  const first = nodeMap.get(path.nodes[0]);
  if (!first) return segments;
  let current: FloorSegment = { floor: first.floor, nodeIds: [first.id], steps: [], distance: 0 };

  for (const step of path.steps) {
    if (step.kind === "stair" || step.kind === "lift") {
      current.transition = {
        kind: step.kind,
        to: step.to.floor,
        label: step.kind === "lift" ? "Take the lift" : "Take the staircase",
      };
      current.steps.push(step);
      current.nodeIds.push(step.to.id);
      segments.push(current);
      current = { floor: step.to.floor, nodeIds: [step.to.id], steps: [], distance: 0 };
      continue;
    }
    current.steps.push(step);
    current.nodeIds.push(step.to.id);
    current.distance += step.distance;
  }
  segments.push(current);
  return segments.filter((s) => s.nodeIds.length > 1 || segments.length === 1);
}

/** The floor the user should be looking at for a given step index. */
export function floorForStep(plan: RoutePlan, stepIndex: number): FloorId {
  let i = 0;
  for (const seg of plan.segments) {
    if (stepIndex < i + seg.steps.length) return seg.floor;
    i += seg.steps.length;
  }
  return plan.end.floor;
}

/** Human summary, e.g. "Ground Floor → First Floor via staircase". */
export function transitionSummary(plan: RoutePlan): string[] {
  return plan.segments
    .filter((s) => s.transition)
    .map((s) => `${s.transition!.label} from floor ${s.floor} to floor ${s.transition!.to}`);
}
