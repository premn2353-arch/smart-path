// Live occupancy domain model — pure logic, no UI, no storage.
// Swap the sample defaults for a Supabase-backed source later: the rest of the
// app only depends on the types and helpers in this file.

export type CrowdStatus = "low" | "medium" | "high" | "over";

/** A place whose crowd level is tracked. Either a campus node or a whole floor. */
export interface OccupancyLocation {
  /** Tracking id. For nodes this equals the campus node id; floors use `floor-<n>`. */
  id: string;
  name: string;
  /** Campus node id, when the tracked location maps onto the indoor map. */
  nodeId?: string;
  /** Floor level for floor-wide counters. */
  floor?: number;
  kind: "place" | "floor";
}

export interface OccupancyRecord {
  locationId: string;
  capacity: number;
  current: number;
  /** Admin switch — when false the location is not tracked / not shown as live. */
  enabled: boolean;
  updatedAt: number;
}

/** A check-in held by the current anonymous browser session. */
export interface CheckIn {
  locationId: string;
  at: number;
}

export const OCCUPANCY_LOCATIONS: OccupancyLocation[] = [
  { id: "library", name: "Library", nodeId: "library", kind: "place" },
  { id: "canteen", name: "Canteen", nodeId: "canteen", kind: "place" },
  { id: "lab1", name: "Computer Lab 1", nodeId: "lab1", kind: "place" },
  { id: "lab2", name: "Computer Lab 2", nodeId: "lab2", kind: "place" },
  { id: "seminar", name: "Seminar Hall", nodeId: "seminar", kind: "place" },
  { id: "cse", name: "CSE Department", nodeId: "cse", kind: "place" },
  { id: "floor-0", name: "Ground Floor", floor: 0, kind: "floor" },
  { id: "floor-1", name: "First Floor", floor: 1, kind: "floor" },
  { id: "floor-2", name: "Second Floor", floor: 2, kind: "floor" },
];

/** Sample starting data — replace with live data when a backend is connected. */
export const DEFAULT_OCCUPANCY: OccupancyRecord[] = [
  { locationId: "library", capacity: 50, current: 30, enabled: true, updatedAt: 0 },
  { locationId: "canteen", capacity: 120, current: 96, enabled: true, updatedAt: 0 },
  { locationId: "lab1", capacity: 40, current: 12, enabled: true, updatedAt: 0 },
  { locationId: "lab2", capacity: 40, current: 31, enabled: true, updatedAt: 0 },
  { locationId: "seminar", capacity: 150, current: 20, enabled: true, updatedAt: 0 },
  { locationId: "cse", capacity: 60, current: 44, enabled: true, updatedAt: 0 },
  { locationId: "floor-0", capacity: 300, current: 140, enabled: true, updatedAt: 0 },
  { locationId: "floor-1", capacity: 300, current: 205, enabled: true, updatedAt: 0 },
  { locationId: "floor-2", capacity: 300, current: 68, enabled: true, updatedAt: 0 },
];

/** Occupancy % = (current / capacity) * 100 */
export function occupancyPercent(current: number, capacity: number): number {
  if (capacity <= 0) return 0;
  return Math.round((current / capacity) * 100);
}

export function crowdStatus(percent: number): CrowdStatus {
  if (percent > 100) return "over";
  if (percent >= 71) return "high";
  if (percent >= 41) return "medium";
  return "low";
}

export const CROWD_LABEL: Record<CrowdStatus, string> = {
  low: "Low Crowd",
  medium: "Medium Crowd",
  high: "High Crowd",
  over: "Over Capacity",
};

export interface OccupancyView extends OccupancyRecord {
  id: string;
  name: string;
  kind: OccupancyLocation["kind"];
  nodeId?: string;
  percent: number;
  status: CrowdStatus;
  label: string;
}

export function toView(rec: OccupancyRecord, loc: OccupancyLocation): OccupancyView {
  const percent = occupancyPercent(rec.current, rec.capacity);
  const status = crowdStatus(percent);
  return {
    ...rec,
    id: loc.id,
    name: loc.name,
    kind: loc.kind,
    nodeId: loc.nodeId,
    percent,
    status,
    label: CROWD_LABEL[status],
  };
}

/** Extra routing cost (in "meters") for passing through a crowded location. */
export function crowdPenalty(percent: number): number {
  if (percent <= 40) return 0;
  return Math.round((percent - 40) * 0.9);
}
