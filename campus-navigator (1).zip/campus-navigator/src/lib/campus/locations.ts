// Sample indoor map data. Coordinates are percentages (0-100) of each floor
// plan, so real plan images can be dropped in later without moving nodes.
// Replace everything in this file with real college data — the rest of the app
// only depends on the types in `model.ts`.

import type { Building, Campus, CampusNode, Floor } from "./model";

export const CAMPUS: Campus = {
  id: "campus-main",
  name: "Our Campus",
  address: "Main Campus — replace with the real college address",
};

export const BUILDINGS: Building[] = [
  {
    id: "grounds",
    name: "Campus Grounds",
    campusId: CAMPUS.id,
    description: "Outdoor area: main gate, pathways and emergency assembly points.",
  },
  {
    id: "main-block",
    name: "Main Academic Block",
    campusId: CAMPUS.id,
    description: "Ground, first and second floors — classrooms, labs and departments.",
  },
];

export const FLOORS: Floor[] = [
  { id: 0, name: "Ground Floor", slug: "ground", level: 0, buildingId: "main-block" },
  { id: 1, name: "First Floor", slug: "first", level: 1, buildingId: "main-block" },
  { id: 2, name: "Second Floor", slug: "second", level: 2, buildingId: "main-block" },
];

export const floorBySlug = (slug: string): Floor | undefined =>
  FLOORS.find((f) => f.slug === slug);

export const floorById = (id: number): Floor | undefined => FLOORS.find((f) => f.id === id);

// -------- Ground Floor --------
const ground: CampusNode[] = [
  { id: "gate", label: "Main Gate", type: "gate", floor: 0, buildingId: "grounds", x: 50, y: 92, accessible: true, hasQr: true, aliases: ["entrance", "front gate"], isDestination: true },
  { id: "entrance-main", label: "Main Block Entrance", type: "entrance", floor: 0, buildingId: "main-block", x: 50, y: 83, accessible: true, hasQr: true },
  { id: "reception", label: "Reception", type: "landmark", floor: 0, buildingId: "main-block", x: 50, y: 75, accessible: true, hasQr: true, isDestination: true, aliases: ["front desk", "enquiry"] },
  { id: "corr-g1", label: "Corridor G-A", type: "corridor", floor: 0, buildingId: "main-block", x: 30, y: 70, accessible: true },
  { id: "corr-g2", label: "Corridor G-B", type: "corridor", floor: 0, buildingId: "main-block", x: 70, y: 70, accessible: true },
  { id: "corr-g3", label: "Corridor G-C", type: "corridor", floor: 0, buildingId: "main-block", x: 50, y: 55, accessible: true },
  { id: "principal", label: "Principal Office", type: "department", floor: 0, buildingId: "main-block", x: 15, y: 65, code: "G-01", isDestination: true, accessible: true },
  { id: "admin", label: "Administrative Office", type: "department", floor: 0, buildingId: "main-block", x: 15, y: 50, code: "G-02", isDestination: true, accessible: true, aliases: ["admin", "office", "fees"] },
  { id: "canteen", label: "Canteen", type: "landmark", floor: 0, buildingId: "main-block", x: 85, y: 65, isDestination: true, accessible: true, aliases: ["cafeteria", "food"] },
  { id: "library", label: "Library", type: "landmark", floor: 0, buildingId: "main-block", x: 85, y: 45, isDestination: true, accessible: true, aliases: ["books", "reading room"] },
  { id: "class101", label: "Classroom 101", type: "room", floor: 0, buildingId: "main-block", x: 30, y: 40, code: "101", isDestination: true, accessible: true },
  { id: "washroom-g", label: "Washroom (Ground)", type: "washroom", floor: 0, buildingId: "main-block", x: 70, y: 50, isDestination: true, accessible: true, aliases: ["toilet", "restroom"] },
  { id: "stair-1-g", label: "Staircase 1 (G)", type: "stair", floor: 0, buildingId: "main-block", x: 40, y: 55, accessible: false, hasQr: true },
  { id: "stair-2-g", label: "Staircase 2 (G)", type: "stair", floor: 0, buildingId: "main-block", x: 60, y: 55, accessible: false, hasQr: true },
  { id: "lift-g", label: "Lift (G)", type: "lift", floor: 0, buildingId: "main-block", x: 55, y: 65, accessible: true, hasQr: true },
  { id: "exit-back", label: "Emergency Exit (Back)", type: "exit", floor: 0, buildingId: "main-block", x: 50, y: 10, isEmergencyExit: true, accessible: true },
  { id: "exit-side", label: "Emergency Exit (Side)", type: "exit", floor: 0, buildingId: "main-block", x: 5, y: 80, isEmergencyExit: true, accessible: true },
];

// -------- First Floor --------
const first: CampusNode[] = [
  { id: "corr-1a", label: "Corridor 1-A", type: "corridor", floor: 1, buildingId: "main-block", x: 30, y: 70, accessible: true },
  { id: "corr-1b", label: "Corridor 1-B", type: "corridor", floor: 1, buildingId: "main-block", x: 70, y: 70, accessible: true },
  { id: "corr-1c", label: "Corridor 1-C", type: "corridor", floor: 1, buildingId: "main-block", x: 50, y: 55, accessible: true },
  { id: "cse", label: "CSE Department", type: "department", floor: 1, buildingId: "main-block", x: 20, y: 55, code: "1-01", isDestination: true, accessible: true, aliases: ["computer science", "cs dept"] },
  { id: "ece", label: "ECE Department", type: "department", floor: 1, buildingId: "main-block", x: 80, y: 70, code: "1-02", isDestination: true, accessible: true, aliases: ["electronics"] },
  { id: "lab1", label: "Computer Lab 1", type: "lab", floor: 1, buildingId: "main-block", x: 20, y: 40, code: "1-11", isDestination: true, accessible: true, aliases: ["programming lab"] },
  { id: "lab2", label: "Computer Lab 2", type: "lab", floor: 1, buildingId: "main-block", x: 80, y: 40, code: "1-12", isDestination: true, accessible: true },
  { id: "seminar", label: "Seminar Hall", type: "landmark", floor: 1, buildingId: "main-block", x: 80, y: 55, isDestination: true, accessible: true, aliases: ["auditorium"] },
  { id: "class201", label: "Classroom 201", type: "room", floor: 1, buildingId: "main-block", x: 50, y: 30, code: "201", isDestination: true, accessible: true },
  { id: "stair-1-1", label: "Staircase 1 (1F)", type: "stair", floor: 1, buildingId: "main-block", x: 40, y: 55, accessible: false, hasQr: true },
  { id: "stair-2-1", label: "Staircase 2 (1F)", type: "stair", floor: 1, buildingId: "main-block", x: 60, y: 55, accessible: false, hasQr: true },
  { id: "lift-1", label: "Lift (1F)", type: "lift", floor: 1, buildingId: "main-block", x: 55, y: 65, accessible: true, hasQr: true },
  { id: "exit-1", label: "Emergency Exit (1F)", type: "exit", floor: 1, buildingId: "main-block", x: 50, y: 10, isEmergencyExit: true, accessible: true },
];

// -------- Second Floor --------
const second: CampusNode[] = [
  { id: "corr-2a", label: "Corridor 2-A", type: "corridor", floor: 2, buildingId: "main-block", x: 40, y: 60, accessible: true },
  { id: "corr-2b", label: "Corridor 2-B", type: "corridor", floor: 2, buildingId: "main-block", x: 60, y: 60, accessible: true },
  { id: "class301", label: "Classroom 301", type: "room", floor: 2, buildingId: "main-block", x: 30, y: 40, code: "301", isDestination: true, accessible: true },
  { id: "physics-lab", label: "Physics Lab", type: "lab", floor: 2, buildingId: "main-block", x: 70, y: 40, code: "3-11", isDestination: true, accessible: true },
  { id: "mech", label: "Mechanical Department", type: "department", floor: 2, buildingId: "main-block", x: 75, y: 70, code: "2-02", isDestination: true, accessible: true, aliases: ["mech dept"] },
  { id: "stair-1-2", label: "Staircase 1 (2F)", type: "stair", floor: 2, buildingId: "main-block", x: 40, y: 55, accessible: false, hasQr: true },
  { id: "stair-2-2", label: "Staircase 2 (2F)", type: "stair", floor: 2, buildingId: "main-block", x: 60, y: 55, accessible: false, hasQr: true },
  { id: "lift-2", label: "Lift (2F)", type: "lift", floor: 2, buildingId: "main-block", x: 55, y: 65, accessible: true, hasQr: true },
  { id: "exit-2", label: "Emergency Exit (2F)", type: "exit", floor: 2, buildingId: "main-block", x: 50, y: 10, isEmergencyExit: true, accessible: true },
];

export const NODES: CampusNode[] = [...ground, ...first, ...second];
