// Persistent occupancy store. Currently localStorage-backed so the feature
// works without a backend; the API (async-friendly, id-based) mirrors what a
// Supabase table (`occupancy` + `occupancy_events`) would expose.

import { useEffect, useState, useSyncExternalStore } from "react";
import {
  DEFAULT_OCCUPANCY,
  OCCUPANCY_LOCATIONS,
  toView,
  type CheckIn,
  type OccupancyRecord,
  type OccupancyView,
} from "./occupancy";

const KEY = "campus-occupancy-v1";
const SESSION_KEY = "campus-occupancy-session-v1";

interface OccState {
  records: OccupancyRecord[];
  /** Check-ins held by this anonymous browser session (never shown publicly). */
  checkIns: CheckIn[];
}

const DEFAULTS: OccState = { records: DEFAULT_OCCUPANCY, checkIns: [] };

let state: OccState = load();
const listeners = new Set<() => void>();

function load(): OccState {
  if (typeof window === "undefined") return DEFAULTS;
  try {
    const raw = window.localStorage.getItem(KEY);
    const records = raw ? (JSON.parse(raw) as OccupancyRecord[]) : DEFAULT_OCCUPANCY;
    const rawS = window.localStorage.getItem(SESSION_KEY);
    const checkIns = rawS ? (JSON.parse(rawS) as CheckIn[]) : [];
    return { records, checkIns };
  } catch {
    return DEFAULTS;
  }
}

function persist() {
  if (typeof window !== "undefined") {
    window.localStorage.setItem(KEY, JSON.stringify(state.records));
    window.localStorage.setItem(SESSION_KEY, JSON.stringify(state.checkIns));
  }
  listeners.forEach((l) => l());
}

function patch(id: string, fn: (r: OccupancyRecord) => OccupancyRecord) {
  state = {
    ...state,
    records: state.records.map((r) => (r.locationId === id ? fn(r) : r)),
  };
}

/** Locations a scanned campus node counts towards (the place plus its floor). */
export function trackedIdsForNode(nodeId: string, floor: number): string[] {
  const ids: string[] = [];
  if (OCCUPANCY_LOCATIONS.some((l) => l.nodeId === nodeId)) ids.push(nodeId);
  if (OCCUPANCY_LOCATIONS.some((l) => l.id === `floor-${floor}`)) ids.push(`floor-${floor}`);
  return ids;
}

export const occupancyStore = {
  getState: () => state,
  subscribe: (l: () => void) => {
    listeners.add(l);
    return () => listeners.delete(l);
  },
  isCheckedIn: (id: string) => state.checkIns.some((c) => c.locationId === id),
  /** Increase the count once per session per location. */
  checkIn: (ids: string[]) => {
    const now = Date.now();
    for (const id of ids) {
      const rec = state.records.find((r) => r.locationId === id);
      if (!rec || !rec.enabled) continue;
      if (state.checkIns.some((c) => c.locationId === id)) continue; // no double check-in
      patch(id, (r) => ({ ...r, current: r.current + 1, updatedAt: now }));
      state = { ...state, checkIns: [...state.checkIns, { locationId: id, at: now }] };
    }
    persist();
  },
  checkOut: (ids: string[]) => {
    const now = Date.now();
    for (const id of ids) {
      if (!state.checkIns.some((c) => c.locationId === id)) continue;
      patch(id, (r) => ({ ...r, current: Math.max(0, r.current - 1), updatedAt: now }));
      state = { ...state, checkIns: state.checkIns.filter((c) => c.locationId !== id) };
    }
    persist();
  },
  checkOutAll: () => {
    occupancyStore.checkOut(state.checkIns.map((c) => c.locationId));
  },
  // --- admin operations ---
  setCapacity: (id: string, capacity: number) => {
    patch(id, (r) => ({ ...r, capacity: Math.max(1, capacity), updatedAt: Date.now() }));
    persist();
  },
  setCurrent: (id: string, current: number) => {
    patch(id, (r) => ({ ...r, current: Math.max(0, current), updatedAt: Date.now() }));
    persist();
  },
  adjust: (id: string, delta: number) => {
    patch(id, (r) => ({ ...r, current: Math.max(0, r.current + delta), updatedAt: Date.now() }));
    persist();
  },
  setEnabled: (id: string, enabled: boolean) => {
    patch(id, (r) => ({ ...r, enabled, updatedAt: Date.now() }));
    persist();
  },
  resetLocation: (id: string) => {
    patch(id, (r) => ({ ...r, current: 0, updatedAt: Date.now() }));
    state = { ...state, checkIns: state.checkIns.filter((c) => c.locationId !== id) };
    persist();
  },
  resetAll: () => {
    state = { records: DEFAULT_OCCUPANCY.map((r) => ({ ...r })), checkIns: [] };
    persist();
  },
};

function buildViews(records: OccupancyRecord[]): OccupancyView[] {
  return OCCUPANCY_LOCATIONS.map((loc) => {
    const rec =
      records.find((r) => r.locationId === loc.id) ??
      ({ locationId: loc.id, capacity: 50, current: 0, enabled: true, updatedAt: 0 } as OccupancyRecord);
    return toView(rec, loc);
  });
}

const SERVER_SNAPSHOT = buildViews(DEFAULT_OCCUPANCY);

/** All tracked locations with percentage + crowd status, anonymous counts only. */
export function useOccupancy(): { views: OccupancyView[]; checkIns: CheckIn[]; hydrated: boolean } {
  const [hydrated, setHydrated] = useState(false);
  useEffect(() => setHydrated(true), []);
  const snap = useSyncExternalStore(
    occupancyStore.subscribe,
    () => occupancyStore.getState(),
    () => DEFAULTS,
  );
  if (!hydrated) return { views: SERVER_SNAPSHOT, checkIns: [], hydrated };
  return { views: buildViews(snap.records), checkIns: snap.checkIns, hydrated };
}

/** Occupancy for a single campus node id, if that node is tracked. */
export function useNodeOccupancy(nodeId: string | null | undefined): OccupancyView | null {
  const { views } = useOccupancy();
  if (!nodeId) return null;
  return views.find((v) => v.nodeId === nodeId && v.enabled) ?? null;
}
