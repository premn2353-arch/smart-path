// Indoor navigation graph: walkable connections between locations.
// Nodes live in `locations.ts`; this file only describes how they connect.
// Stairs and lifts are edges between floors.

import type { CampusEdge } from "./model";

const w = (
  a: string,
  b: string,
  weight: number,
  kind: CampusEdge["kind"] = "walk",
  accessible = true,
): CampusEdge => ({
  from: a,
  to: b,
  weight,
  kind,
  accessible: kind === "stair" ? false : accessible,
});

export const EDGES: CampusEdge[] = [
  // ---- Ground floor ----
  w("gate", "entrance-main", 8),
  w("entrance-main", "reception", 8),
  w("reception", "corr-g1", 12),
  w("reception", "corr-g2", 12),
  w("reception", "corr-g3", 18),
  w("corr-g1", "principal", 10),
  w("corr-g1", "admin", 14),
  w("corr-g1", "class101", 18),
  w("corr-g2", "canteen", 10),
  w("corr-g2", "library", 18),
  w("corr-g2", "washroom-g", 14),
  w("corr-g3", "stair-1-g", 8),
  w("corr-g3", "stair-2-g", 8),
  w("reception", "lift-g", 10),
  w("corr-g3", "exit-back", 40),
  w("corr-g1", "exit-side", 20),

  // ---- Vertical connections (stairs & lifts) ----
  w("stair-1-g", "stair-1-1", 6, "stair"),
  w("stair-2-g", "stair-2-1", 6, "stair"),
  w("stair-1-1", "stair-1-2", 6, "stair"),
  w("stair-2-1", "stair-2-2", 6, "stair"),
  w("lift-g", "lift-1", 4, "lift"),
  w("lift-1", "lift-2", 4, "lift"),

  // ---- First floor ----
  w("stair-1-1", "corr-1c", 6),
  w("stair-2-1", "corr-1c", 6),
  w("lift-1", "corr-1c", 8),
  w("corr-1c", "corr-1a", 12),
  w("corr-1c", "corr-1b", 12),
  w("corr-1a", "cse", 10),
  w("corr-1a", "lab1", 16),
  w("corr-1b", "lab2", 16),
  w("corr-1b", "seminar", 10),
  w("corr-1b", "ece", 10),
  w("corr-1c", "class201", 20),
  w("corr-1c", "exit-1", 40),

  // ---- Second floor ----
  w("stair-1-2", "corr-2a", 6),
  w("stair-2-2", "corr-2b", 6),
  w("lift-2", "corr-2b", 8),
  w("corr-2a", "corr-2b", 15),
  w("corr-2a", "class301", 14),
  w("corr-2b", "physics-lab", 14),
  w("corr-2b", "mech", 12),
  w("corr-2a", "exit-2", 40),
];

/** Adjacency list built from EDGES — handy for pathfinding (A*, Dijkstra). */
export function buildAdjacency(edges: CampusEdge[] = EDGES) {
  const adj = new Map<string, { to: string; edge: CampusEdge }[]>();
  for (const e of edges) {
    if (!adj.has(e.from)) adj.set(e.from, []);
    if (!adj.has(e.to)) adj.set(e.to, []);
    adj.get(e.from)!.push({ to: e.to, edge: e });
    adj.get(e.to)!.push({ to: e.from, edge: e });
  }
  return adj;
}
