// Local persistent store for campus data. Backed by localStorage so admins can
// build a real campus (buildings, floors, floor-plan images, locations and the
// navigation graph) without a backend. The API is intentionally id-based and
// side-effect free so it can be swapped for a Supabase-backed source later.

import { useEffect, useState, useSyncExternalStore } from "react";
import {
  BUILDINGS,
  EDGES,
  FLOORS,
  NODES,
  type Building,
  type CampusEdge,
  type CampusNode,
  type Floor,
  type FloorId,
} from "./data";

// Bump the version whenever the shape of the sample data changes so cached
// copies in the browser don't shadow the new indoor map model.
const KEY = "campus-data-v3";
const CURRENT_KEY = "campus-current-location";

interface CampusData {
  nodes: CampusNode[];
  edges: CampusEdge[];
  buildings: Building[];
  floors: Floor[];
}

const DEFAULTS: CampusData = {
  nodes: NODES,
  edges: EDGES,
  buildings: BUILDINGS,
  floors: FLOORS,
};

let state: CampusData = load();
const listeners = new Set<() => void>();

function load(): CampusData {
  if (typeof window === "undefined") return DEFAULTS;
  try {
    const raw = window.localStorage.getItem(KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<CampusData>;
      return {
        nodes: parsed.nodes ?? NODES,
        edges: parsed.edges ?? EDGES,
        buildings: parsed.buildings ?? BUILDINGS,
        floors: parsed.floors ?? FLOORS,
      };
    }
  } catch {
    /* ignore */
  }
  return DEFAULTS;
}

function persist() {
  if (typeof window !== "undefined") {
    try {
      window.localStorage.setItem(KEY, JSON.stringify(state));
    } catch {
      // Most likely the quota was exceeded by large floor-plan images.
      console.warn("Campus data could not be saved locally (storage full).");
    }
  }
  listeners.forEach((l) => l());
}

const sameEdge = (e: CampusEdge, from: string, to: string) =>
  (e.from === from && e.to === to) || (e.from === to && e.to === from);

export const campusStore = {
  getState: () => state,
  subscribe: (l: () => void) => {
    listeners.add(l);
    return () => listeners.delete(l);
  },
  setNodes: (nodes: CampusNode[]) => {
    state = { ...state, nodes };
    persist();
  },
  setEdges: (edges: CampusEdge[]) => {
    state = { ...state, edges };
    persist();
  },
  updateNode: (id: string, patch: Partial<CampusNode>) => {
    state = {
      ...state,
      nodes: state.nodes.map((n) => (n.id === id ? { ...n, ...patch } : n)),
    };
    persist();
  },
  addNode: (n: CampusNode) => {
    state = { ...state, nodes: [...state.nodes, n] };
    persist();
  },
  removeNode: (id: string) => {
    state = {
      ...state,
      nodes: state.nodes.filter((n) => n.id !== id),
      edges: state.edges.filter((e) => e.from !== id && e.to !== id),
    };
    persist();
  },

  // ---- navigation graph -------------------------------------------------
  addEdge: (edge: CampusEdge) => {
    if (edge.from === edge.to) return;
    if (state.edges.some((e) => sameEdge(e, edge.from, edge.to))) return;
    state = { ...state, edges: [...state.edges, edge] };
    persist();
  },
  updateEdge: (from: string, to: string, patch: Partial<CampusEdge>) => {
    state = {
      ...state,
      edges: state.edges.map((e) => (sameEdge(e, from, to) ? { ...e, ...patch } : e)),
    };
    persist();
  },
  removeEdge: (from: string, to: string) => {
    state = { ...state, edges: state.edges.filter((e) => !sameEdge(e, from, to)) };
    persist();
  },
  toggleEdgeBlocked: (from: string, to: string) => {
    state = {
      ...state,
      edges: state.edges.map((e) => (sameEdge(e, from, to) ? { ...e, blocked: !e.blocked } : e)),
    };
    persist();
  },

  // ---- buildings --------------------------------------------------------
  addBuilding: (b: Building) => {
    state = { ...state, buildings: [...state.buildings, b] };
    persist();
  },
  updateBuilding: (id: string, patch: Partial<Building>) => {
    state = {
      ...state,
      buildings: state.buildings.map((b) => (b.id === id ? { ...b, ...patch } : b)),
    };
    persist();
  },
  removeBuilding: (id: string) => {
    state = { ...state, buildings: state.buildings.filter((b) => b.id !== id) };
    persist();
  },

  // ---- floors & floor plans --------------------------------------------
  addFloor: (f: Floor) => {
    if (state.floors.some((x) => x.id === f.id || x.slug === f.slug)) return;
    state = { ...state, floors: [...state.floors, f].sort((a, b) => a.level - b.level) };
    persist();
  },
  updateFloor: (id: FloorId, patch: Partial<Floor>) => {
    state = {
      ...state,
      floors: state.floors
        .map((f) => (f.id === id ? { ...f, ...patch } : f))
        .sort((a, b) => a.level - b.level),
    };
    persist();
  },
  removeFloor: (id: FloorId) => {
    const nodeIds = new Set(state.nodes.filter((n) => n.floor === id).map((n) => n.id));
    state = {
      ...state,
      floors: state.floors.filter((f) => f.id !== id),
      nodes: state.nodes.filter((n) => !nodeIds.has(n.id)),
      edges: state.edges.filter((e) => !nodeIds.has(e.from) && !nodeIds.has(e.to)),
    };
    persist();
  },
  /** Set or replace the floor-plan image (data URL) shown behind the map. */
  setFloorPlan: (id: FloorId, planImage: string | undefined) => {
    campusStore.updateFloor(id, { planImage });
  },

  reset: () => {
    state = { ...DEFAULTS };
    persist();
  },
};

export function useCampus(): CampusData {
  // SSR-safe: return defaults on server, hydrate on client.
  const [hydrated, setHydrated] = useState(false);
  useEffect(() => setHydrated(true), []);
  const snap = useSyncExternalStore(
    campusStore.subscribe,
    () => campusStore.getState(),
    () => DEFAULTS,
  );
  return hydrated ? snap : DEFAULTS;
}

/** Floors sorted by level, from the live store. */
export function useFloors(): Floor[] {
  return useCampus().floors;
}

// ---------------------------------------------------------------------------
// Current indoor location (set by the QR scanner checkpoints)
// ---------------------------------------------------------------------------

let currentLocationId: string | null =
  typeof window === "undefined" ? null : window.localStorage.getItem(CURRENT_KEY);
const currentListeners = new Set<() => void>();

export const currentLocationStore = {
  get: () => currentLocationId,
  set: (id: string | null) => {
    currentLocationId = id;
    if (typeof window !== "undefined") {
      if (id) window.localStorage.setItem(CURRENT_KEY, id);
      else window.localStorage.removeItem(CURRENT_KEY);
    }
    currentListeners.forEach((l) => l());
  },
  subscribe: (l: () => void) => {
    currentListeners.add(l);
    return () => currentListeners.delete(l);
  },
};

/** The location the user last checked in at via a QR checkpoint. */
export function useCurrentLocation(): CampusNode | null {
  const { nodes } = useCampus();
  const [hydrated, setHydrated] = useState(false);
  useEffect(() => setHydrated(true), []);
  const id = useSyncExternalStore(
    currentLocationStore.subscribe,
    () => currentLocationStore.get(),
    () => null,
  );
  if (!hydrated || !id) return null;
  return nodes.find((n) => n.id === id) ?? null;
}
