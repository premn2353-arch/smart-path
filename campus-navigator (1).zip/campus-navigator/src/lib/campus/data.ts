// Backwards-compatible barrel for the indoor map system.
// Types live in `model.ts`, sample locations in `locations.ts`, and the
// navigation graph in `connections.ts`.

export type {
  Building,
  Campus,
  CampusEdge,
  CampusNode,
  Floor,
  FloorId,
  LocationType,
  NodeType,
} from "./model";

export { BUILDINGS, CAMPUS, FLOORS, NODES, floorById, floorBySlug } from "./locations";
export { EDGES, buildAdjacency } from "./connections";
