// Dijkstra shortest path over the campus graph.
// Isolated from UI so it can be swapped for A*, live weights, etc.

import type { CampusEdge, CampusNode } from "./data";

export type RouteMode =
  | "shortest"
  | "fastest"
  | "lift"
  | "stair"
  | "accessible"
  | "less-crowded"
  | "emergency";

export interface PathResult {
  nodes: string[];
  distance: number; // meters
  minutes: number; // approx walking time
  floors: number; // number of distinct floors traversed
  steps: RouteStep[];
}

export interface RouteStep {
  from: CampusNode;
  to: CampusNode;
  kind: "walk" | "stair" | "lift";
  instruction: string;
  distance: number;
}

const WALKING_SPEED_M_PER_MIN = 60; // ~3.6 km/h indoor

function edgeAllowed(e: CampusEdge, mode: RouteMode): boolean {
  if (e.blocked && mode !== "emergency") return false;
  if (mode === "accessible" && !e.accessible) return false;
  if (mode === "stair" && e.kind === "lift") return false;
  if (mode === "lift" && e.kind === "stair") return false;
  return true;
}

function edgeCost(e: CampusEdge, mode: RouteMode): number {
  let cost = e.weight;
  if (mode === "fastest") {
    if (e.kind === "stair") cost *= 2.2;
    if (e.kind === "lift") cost *= 1.4;
  }
  if (mode === "lift" && e.kind === "lift") cost *= 0.5;
  if (mode === "stair" && e.kind === "stair") cost *= 0.7;
  if (mode === "emergency" && e.kind === "lift") cost *= 3; // avoid lifts in emergencies
  return cost;
}

// Heuristic for A*: Euclidean distance on the abstract grid + per-floor penalty.
// Units are intentionally in the same ballpark as edge weights (meters) so the
// heuristic stays admissible for typical campus edge lengths.
const FLOOR_PENALTY = 4;
function heuristic(a: CampusNode, b: CampusNode): number {
  const dx = a.x - b.x;
  const dy = a.y - b.y;
  const df = Math.abs(a.floor - b.floor);
  return Math.sqrt(dx * dx + dy * dy) + df * FLOOR_PENALTY;
}

/** Extra per-node cost, used for crowd-aware routing. */
export interface PathOptions {
  nodeCost?: Map<string, number>;
}

export function findPath(
  nodes: CampusNode[],
  edges: CampusEdge[],
  startId: string,
  endId: string,
  mode: RouteMode = "shortest",
  opts: PathOptions = {},
): PathResult | null {
  const nodeMap = new Map(nodes.map((n) => [n.id, n]));
  const start = nodeMap.get(startId);
  const end = nodeMap.get(endId);
  if (!start || !end) return null;

  const adj = new Map<string, { to: string; edge: CampusEdge }[]>();
  for (const n of nodes) adj.set(n.id, []);
  for (const e of edges) {
    if (!edgeAllowed(e, mode)) continue;
    adj.get(e.from)?.push({ to: e.to, edge: e });
    adj.get(e.to)?.push({ to: e.from, edge: e });
  }

  // A* search
  const gScore = new Map<string, number>();
  const fScore = new Map<string, number>();
  const prev = new Map<string, { id: string; edge: CampusEdge } | null>();
  for (const n of nodes) {
    gScore.set(n.id, Infinity);
    fScore.set(n.id, Infinity);
    prev.set(n.id, null);
  }
  gScore.set(startId, 0);
  fScore.set(startId, heuristic(start, end));

  const open = new Set<string>([startId]);
  const closed = new Set<string>();

  while (open.size) {
    // pick lowest fScore in open (small graph — linear scan is fine)
    let current: string | null = null;
    let bestF = Infinity;
    for (const id of open) {
      const f = fScore.get(id)!;
      if (f < bestF) {
        bestF = f;
        current = id;
      }
    }
    if (current === null) break;
    if (current === endId) break;
    open.delete(current);
    closed.add(current);

    const currentG = gScore.get(current)!;
    for (const { to, edge } of adj.get(current) ?? []) {
      if (closed.has(to)) continue;
      const tentative = currentG + edgeCost(edge, mode) + (opts.nodeCost?.get(to) ?? 0);
      if (tentative < gScore.get(to)!) {
        prev.set(to, { id: current, edge });
        gScore.set(to, tentative);
        fScore.set(to, tentative + heuristic(nodeMap.get(to)!, end));
        open.add(to);
      }
    }
  }

  if (gScore.get(endId) === Infinity) return null;

  // Reconstruct
  const pathIds: string[] = [];
  const stepsRev: RouteStep[] = [];
  let cur: string | null = endId;
  let totalRealDist = 0;
  const floorSet = new Set<number>();
  while (cur) {
    pathIds.push(cur);
    floorSet.add(nodeMap.get(cur)!.floor);
    const p = prev.get(cur);
    if (!p) break;
    const fromNode = nodeMap.get(p.id)!;
    const toNode = nodeMap.get(cur)!;
    totalRealDist += p.edge.weight;
    stepsRev.push({
      from: fromNode,
      to: toNode,
      kind: p.edge.kind,
      distance: p.edge.weight,
      instruction: buildInstruction(fromNode, toNode, p.edge),
    });
    cur = p.id;
  }
  pathIds.reverse();
  stepsRev.reverse();

  return {
    nodes: pathIds,
    distance: Math.round(totalRealDist),
    minutes: Math.max(1, Math.round(totalRealDist / WALKING_SPEED_M_PER_MIN)),
    floors: floorSet.size,
    steps: withTurnHints(stepsRev),
  };
}

// Add "turn left/right/continue straight" hints between consecutive walk steps.
function withTurnHints(steps: RouteStep[]): RouteStep[] {
  if (steps.length === 0) return steps;
  const out: RouteStep[] = [{ ...steps[0], instruction: `Start at ${steps[0].from.label}. ${steps[0].instruction}` }];
  for (let i = 1; i < steps.length; i++) {
    const prev = steps[i - 1];
    const cur = steps[i];
    let hint = "";
    if (cur.kind === "walk" && prev.kind === "walk") {
      const ax = prev.to.x - prev.from.x;
      const ay = prev.to.y - prev.from.y;
      const bx = cur.to.x - cur.from.x;
      const by = cur.to.y - cur.from.y;
      const cross = ax * by - ay * bx;
      const dot = ax * bx + ay * by;
      const angle = Math.atan2(cross, dot) * (180 / Math.PI);
      if (angle > 25) hint = "Turn right, then ";
      else if (angle < -25) hint = "Turn left, then ";
      else if (Math.abs(angle) < 10) hint = "Continue straight and ";
    }
    out.push({ ...cur, instruction: hint ? hint + cur.instruction.charAt(0).toLowerCase() + cur.instruction.slice(1) : cur.instruction });
  }
  return out;
}

function buildInstruction(from: CampusNode, to: CampusNode, edge: CampusEdge): string {
  if (edge.kind === "stair") {
    const dir = to.floor > from.floor ? "Go up" : "Go down";
    return `${dir} the staircase to ${to.label}`;
  }
  if (edge.kind === "lift") {
    const dir = to.floor > from.floor ? "Take the lift up" : "Take the lift down";
    return `${dir} to ${to.label}`;
  }
  return `Walk to ${to.label} (${Math.round(edge.weight)} m)`;
}

export function nearestEmergencyExit(
  nodes: CampusNode[],
  edges: CampusEdge[],
  startId: string,
): { exitId: string; path: PathResult } | null {
  const exits = nodes.filter((n) => n.isEmergencyExit);
  let best: { exitId: string; path: PathResult } | null = null;
  for (const ex of exits) {
    const p = findPath(nodes, edges, startId, ex.id, "emergency");
    if (!p) continue;
    if (!best || p.distance < best.path.distance) best = { exitId: ex.id, path: p };
  }
  return best;
}
