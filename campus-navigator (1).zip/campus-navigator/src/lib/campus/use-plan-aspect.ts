import { useEffect, useState } from "react";

/**
 * Reads the natural aspect ratio (width / height) of an uploaded floor-plan
 * image so the map canvas can match the plan exactly. Node coordinates stay in
 * a 0-100 percent space, so markers keep aligning with the plan whatever its
 * shape. Returns `undefined` while loading, on the server, or with no plan.
 */
export function usePlanAspect(planImage?: string): number | undefined {
  const [aspect, setAspect] = useState<number | undefined>(undefined);

  useEffect(() => {
    if (!planImage || typeof window === "undefined") {
      setAspect(undefined);
      return;
    }
    let alive = true;
    const img = new Image();
    img.onload = () => {
      if (alive && img.naturalWidth && img.naturalHeight) {
        setAspect(img.naturalWidth / img.naturalHeight);
      }
    };
    img.onerror = () => alive && setAspect(undefined);
    img.src = planImage;
    return () => {
      alive = false;
    };
  }, [planImage]);

  return aspect;
}
