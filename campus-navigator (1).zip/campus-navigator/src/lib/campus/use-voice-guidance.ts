import { useCallback, useEffect, useRef, useState } from "react";

const KEY = "campus-voice-guidance";

/**
 * Spoken turn-by-turn guidance using the browser's built-in speech synthesis.
 * Works offline, needs no API key, and mirrors a desktop TTS engine:
 * a slightly slowed rate (~160 wpm) and full volume.
 */
export function useVoiceGuidance() {
  const [supported, setSupported] = useState(false);
  const [enabled, setEnabled] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const lastSpoken = useRef<string | null>(null);

  useEffect(() => {
    const ok = typeof window !== "undefined" && "speechSynthesis" in window;
    setSupported(ok);
    if (ok) setEnabled(window.localStorage.getItem(KEY) !== "off");
  }, []);

  const cancel = useCallback(() => {
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.cancel();
    }
    setSpeaking(false);
  }, []);

  const speak = useCallback(
    (text: string, opts: { force?: boolean } = {}) => {
      if (!text.trim()) return;
      if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
      if (!enabled) return;
      // Avoid repeating the same instruction on re-renders.
      if (!opts.force && lastSpoken.current === text) return;
      lastSpoken.current = text;

      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.rate = 0.95; // ≈160 words per minute
      u.volume = 1;
      u.pitch = 1;
      u.onstart = () => setSpeaking(true);
      u.onend = () => setSpeaking(false);
      u.onerror = () => setSpeaking(false);
      window.speechSynthesis.speak(u);
    },
    [enabled],
  );

  const toggle = useCallback(() => {
    setEnabled((v) => {
      const next = !v;
      if (typeof window !== "undefined") window.localStorage.setItem(KEY, next ? "on" : "off");
      if (!next) {
        window.speechSynthesis?.cancel();
        setSpeaking(false);
      }
      lastSpoken.current = null;
      return next;
    });
  }, []);

  // Stop talking when the page is left.
  useEffect(() => cancel, [cancel]);

  return { supported, enabled, speaking, speak, cancel, toggle };
}
