// Indoor map domain model.
// Pure types — no UI, no data. Replace the sample data in `locations.ts` and
// `connections.ts` with real college data without touching these types.

export type LocationType =
  | "gate" // campus entrance / main gate
  | "entrance" // building entrance
  | "room" // generic room / classroom
  | "department" // department office
  | "lab" // laboratory
  | "corridor" // walkable corridor junction
  | "stair" // staircase
  | "lift" // elevator
  | "exit" // emergency exit
  | "washroom"
  | "landmark"; // reception, notice board, canteen, library ...

/** Kept for backwards compatibility with earlier code. */
export type NodeType = LocationType;

export type FloorId = number;

export interface Campus {
  id: string;
  name: string;
  /** Free-form address, shown in admin/reference screens. */
  address?: string;
}

export interface Building {
  id: string;
  name: string;
  campusId: string;
  description?: string;
}

export interface Floor {
  id: FloorId;
  /** Which building this floor belongs to. */
  buildingId?: string;
  /** Display name, e.g. "Ground Floor". */
  name: string;
  /** URL-safe slug used in routes: /map/ground */
  slug: string;
  level: number;
  /**
   * Optional real floor-plan image drawn behind the graph. When provided the
   * image is stretched across the whole 0-100 coordinate space, so node x/y
   * values are simply percentages of the plan.
   */
  planImage?: string;
}

export interface CampusNode {
  id: string;
  label: string;
  type: LocationType;
  floor: FloorId;
  /** Which building this location belongs to. */
  buildingId?: string;
  /** Position on the indoor map, 0-100 (percent of the floor plan). */
  x: number;
  y: number;
  /** Room number / short code, e.g. "A-101". */
  code?: string;
  description?: string;
  /** Extra search terms, e.g. ["computer science", "cs dept"]. */
  aliases?: string[];
  /** Selectable as a destination in search. */
  isDestination?: boolean;
  isEmergencyExit?: boolean;
  /** Wheelchair accessible location. */
  accessible?: boolean;
  /** A printed QR checkpoint exists at this location. */
  hasQr?: boolean;
}

export interface CampusEdge {
  from: string;
  to: string;
  /** Approximate walking distance in meters. */
  weight: number;
  kind: "walk" | "stair" | "lift";
  /** Usable in wheelchair / accessible mode. */
  accessible?: boolean;
  blocked?: boolean;
}
