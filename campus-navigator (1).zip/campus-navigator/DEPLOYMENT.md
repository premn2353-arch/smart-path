# Campus Navigator — Production Build & Deployment

This app is a **TanStack Start v1** (React 19 + Vite 8 + Tailwind v4) full-stack app.
The production build is produced by Vite + Nitro, so the same source can be deployed to
a plain Node server, Cloudflare Workers, or any static/SSR host Nitro supports.

---

## 1. Requirements

- Node.js **20+** (22 recommended) or Bun 1.1+
- npm / pnpm / bun (examples below use npm and bun)

## 2. Install dependencies

```bash
npm ci          # or: bun install
```

## 3. Build

### a) Node server (self-hosted VPS, Docker, Render, Railway, Fly.io)

```bash
npm run build:node
```

Output: `.output/` (server bundle + `.output/public` static assets).

### b) Cloudflare Workers / Pages (default preset)

```bash
npm run build
```

Then deploy with `npx wrangler deploy` from `.output/`.

### c) Any other host

Nitro presets are selected with the `NITRO_PRESET` env var:

```bash
NITRO_PRESET=vercel npm run build
NITRO_PRESET=netlify npm run build
NITRO_PRESET=bun npm run build
NITRO_PRESET=node_server npm run build
```

## 4. Start in production

```bash
npm start                       # runs node .output/server/index.mjs
PORT=8080 HOST=0.0.0.0 npm start
```

The server serves both the SSR app and the static assets in `.output/public`.

## 5. Environment variables

- Browser-exposed values must be prefixed `VITE_` and are inlined **at build time**
  (rebuild after changing them).
- Server-only values are read at runtime inside server-function handlers via
  `process.env.X` — set them on the host, not in the bundle.

Create a `.env` for local builds:

```
VITE_APP_NAME=Campus Navigator
```

Never commit real secrets.

## 6. Docker

```dockerfile
FROM node:22-alpine AS build
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build:node

FROM node:22-alpine
WORKDIR /app
ENV NODE_ENV=production PORT=3000 HOST=0.0.0.0
COPY --from=build /app/.output ./.output
EXPOSE 3000
CMD ["node", ".output/server/index.mjs"]
```

```bash
docker build -t campus-navigator .
docker run -p 3000:3000 campus-navigator
```

## 7. Reverse proxy (nginx)

```nginx
server {
  listen 80;
  server_name campus.example.com;
  location / {
    proxy_pass http://127.0.0.1:3000;
    proxy_http_version 1.1;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
  }
}
```

## 8. Bundler configuration

All bundler setup lives in `vite.config.ts` and comes from
`@lovable.dev/vite-tanstack-config`, which already wires up:
TanStack Start, React plugin, Tailwind v4, `tsconfig` path aliases (`@/*`),
Nitro (build-only), and `VITE_*` env injection.

Do **not** add those plugins again — duplicates break the build.
Extra options go through the wrapper:

```ts
export default defineConfig({
  tanstackStart: { server: { entry: "server" } },
  vite: {
    build: { sourcemap: false, chunkSizeWarningLimit: 1200 },
  },
});
```

Never set `ssr.external` / `resolve.external` — the Worker runtime has no
runtime module resolution and the build will fail.

## 9. Pre-deploy checklist

```bash
npm run lint
npm run build:node
npm start          # smoke-test http://localhost:3000
```

- Camera/QR scanning (`html5-qrcode`) and voice guidance (Web Speech API)
  require **HTTPS** in production — terminate TLS at the proxy or host.
- Verify per-floor plan uploads and route rendering after deploy.

## 10. One-click alternative

Click **Publish** in Lovable to deploy the same build to a `*.lovable.app`
URL; a custom domain can be attached in Project settings → Domains.
